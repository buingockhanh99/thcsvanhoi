<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tinnhatruong extends Model
{
    protected $table = "tinnhatruong";

    public $timestamps = false;
}
