<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class vanbantruong extends Model
{
    protected $table = "vanbantruong";

    public $timestamps = false;
}
