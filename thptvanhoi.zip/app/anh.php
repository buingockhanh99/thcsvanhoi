<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class anh extends Model
{
    protected $table = "anh";

    public $timestamps = false;

    
}
