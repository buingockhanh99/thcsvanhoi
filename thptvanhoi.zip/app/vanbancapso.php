<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class vanbancapso extends Model
{
    protected $table = "vanbancapso";

    public $timestamps = false;
}
