<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class hdngoaigiolenlop extends Model
{
    protected $table = "hdngoaigiolenlop";

    public $timestamps = false;
}
