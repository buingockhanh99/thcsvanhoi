<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TinMoiNhat extends Model
{
    protected $table = "tinmoinhat";

    public $timestamps = false;
}
