<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class giaovien extends Model
{
    protected $table = "giaovien";

    public $timestamps = false;

  
}
