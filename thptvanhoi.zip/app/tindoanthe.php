<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tindoanthe extends Model
{
    protected $table = "tindoanthe";

    public $timestamps = false;
}
