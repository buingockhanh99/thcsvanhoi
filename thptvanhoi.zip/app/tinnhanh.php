<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tinnhanh extends Model
{
    protected $table = "tinnhanh";

    public $timestamps = false;
}
