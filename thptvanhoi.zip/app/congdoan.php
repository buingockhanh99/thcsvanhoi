<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class congdoan extends Model
{
    protected $table = "congdoan";

    public $timestamps = false;
}
