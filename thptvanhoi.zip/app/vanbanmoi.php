<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class vanbanmoi extends Model
{
    protected $table = "vanbanmoi";

    public $timestamps = false;
}
