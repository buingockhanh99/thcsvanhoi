<!DOCTYPE html>
<html>
<head>
</head>
<body>


    <h1>{{ $details['title'] }}</h1>
    <p>Tài khoản đăng nhập nhà trường</p>
    <p>UserName <span style="color: red">{{$details['taikhoan']}}</span></p>
    <p>Password <span style="color: red">{{$details['matkhau']}}</span></p>
   

</body>
</html>