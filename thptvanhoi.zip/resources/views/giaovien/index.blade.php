@extends('layout.giaovien')
@section('NoiDung')

      <marquee style="height: 50px; width: 100%;line-height: 50px; font-size: 40px; color: red; margin-top: 30px" direction="left">
        CHÀO MỪNG TỚI TRANG QUẢN TRỊ TRƯỜNG TH & THCS VÂN HỘI
      </marquee>
      
      <h1 style="font-size: 60px; text-align: center;margin-top:10% ">TRANG GIÁO VIÊN</h1>
@endsection

 