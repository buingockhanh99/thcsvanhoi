
<?php $__env->startSection('NoiDung'); ?>

<div class="container-fluid">
    <div style="padding-top: 3%;padding-bottom: 1%; text-align: center">
        <h2 >Quản lý tài khoản</h2>
    </div>
    <div><button class="btn btn-primary" style="width: 200px;"><i class="fas fa-plus"></i><a style="color: #fff" href="<?php echo e(route('addAccoutGV')); ?>"> Thêm tài khoản mới</a></button></div>
    <div style="height: 30px;"></div>

    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
        <tr align="center">
            <th>SĐT</th>
            <th>Tên đăng nhập</th>
            <th>Tên giáo viên</th>
            <th>Email</th>
            <th>Xem thông tin</th>
            
        </tr>
         <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr class="odd gradeX" align="center">
             <td>0<?php echo e($us->id); ?></td>
             <td><?php echo e($us->name); ?></td>
             <td><?php echo e($us->getGV->hoten); ?></td>
             <td><?php echo e($us->email); ?></td>
             <td><a href="admin/thongtingv/<?php echo e($us->id); ?>"><i class="fas fa-eye"></i></a></td>
             
         </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <?php if(session('thongbao')): ?>
    <div class="alert alert-success" style="width: 500px; margin-left: 29%; text-align: center">
        <?php echo e(session('thongbao')); ?>

    </div>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thptvanhoi\resources\views/admin/quanly/taikhoangv.blade.php ENDPATH**/ ?>