<!DOCTYPE html>
<html lang="vi">

<head>
    <title>Trường THPT Vân Hội</title>
    <meta name="author" content="Trường THPT Vân Hội">
    <meta name="copyright" content="Trường THPT Lê Quý Đôn [webmaster@vinades.vn]">
    <meta name="generator" content="NukeViet v4.4">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta property="og:title" content="Trường THPT Lê Quý Đôn">
    <meta property="og:type" content="website">
    <meta property="og:description" content="Tin Tức - Tin Tức - https&#x3A;&#x002F;&#x002F;thptlequydon.edu.vn&#x002F;">
    <meta property="og:site_name" content="Trường THPT Lê Quý Đôn">
    <meta property="og:url" content="https://thptlequydon.edu.vn/">
    
    <link rel="shortcut icon" href="/uploads/thptlequydon/logo_130_130.png">
    <link rel="preload" as="script" href="<?php echo e(asset('js/jquery.min.js')); ?>">
    <link rel="preload" as="script" href="<?php echo e(asset('js/vi.js')); ?>">
    <link rel="preload" as="script" href="<?php echo e(asset('js/global.js')); ?>">
    <link rel="preload" as="script" href="<?php echo e(asset('js/news.js')); ?>">
    <link rel="preload" as="script" href="<?php echo e(asset('js/main.js')); ?>">
    <link rel="preload" as="script" href="<?php echo e(asset('js/jquery.imgpreload.min.js')); ?>">
    <link rel="preload" as="script" href="<?php echo e(asset('js/jquery.slimmenu.js')); ?>">
    <link rel="preload" as="script" href="<?php echo e(asset('js/jquery-ui.min.js')); ?>">
    <link rel="preload" as="script" href="<?php echo e(asset('js/users.js')); ?>">
    <link rel="preload" as="script" href="<?php echo e(asset('js/jquery.breakingnews.js')); ?>">
    <link rel="preload" as="script" href="<?php echo e(asset('js/jquery.marquee.min.js')); ?>">
    <link rel="preload" as="script" href="<?php echo e(asset('js/jwplayer.js')); ?>">
    <link rel="preload" as="script" href="<?php echo e(asset('js/bootstrap.min.js')); ?>">
    <link rel="preload" as="script" href="<?php echo e(asset('js/contentslider.js')); ?>">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
    <link rel="StyleSheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="StyleSheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="StyleSheet" href="<?php echo e(asset('css/style.responsive.css')); ?>">
    <link rel="StyleSheet" href="<?php echo e(asset('css/news.css')); ?>">
    <link rel="StyleSheet" href="<?php echo e(asset('css/edu25.vi.1002.css')); ?>">
    <link rel="StyleSheet" href="<?php echo e(asset('css/users.css')); ?>">
    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(asset('css/slimmenu.css')); ?>" />
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/jquery.breakingnews.css')); ?>" />
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/jquery.ui.tabs.css')); ?>" />
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/contentslider.css')); ?>" />
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
</head>

<body style="font-family: 'Times New Roman', Times, serif">
    <?php if(!isset($thongbao)): ?>

    <?php else: ?>
       <?php echo $thongbao; ?>

    <?php endif; ?>  

    <div class="body-bg">
        <div class="wraper">
            <header>
                <div class="container">
                    <div id="header" class="row">
                        <div class="col-sm-24 col-md-10 logo_title">
                            <div class="logo col-sm-12 col-md-6">
                                <a title="Trường THPT Lê Quý Đôn" href="/"><img src="<?php echo e(asset('images/logo_114_114.png')); ?>" width="114" height="114" alt="Trường THPT Lê Quý Đôn" />
                                </a>
                                <h1>Trường THPT Vân Hội</h1>
                                <h2></h2>
                            </div>

                            <div class="title_banner text-center fl col-sm-12 col-md-18">
                                <p class="room"><a>Sở GD&ĐT Yên Bái</a>
                                </p>

                                <p class="school">
                                    <a data-text="THPT Vân Hội">THPT Vân Hội</a>
                                </p>
                            </div>
                        </div>

                        <div class="banner col-md-14 padding-right">
                            <img src="<?php echo e(asset('images/z2084927071035_fc00389bf2282fbc042a6fa599efa899.jpg')); ?>" width="590px" height="148px" />
                        </div>
                    </div>
                </div>
            </header>
            <nav class="second-nav" id="menusite">
                <div class="container">
                    <div class="row">
                        <div class="col-md-24">
                            <ul class="slimmenu">
                                <li>
                                    <a title="Trang nhất" href="/"><em class="fa fa-lg fa-home">&nbsp;</em> <span class="hidden-sm"> Trang nhất </span></a>
                                </li>
                                <li>
                                    <a title="Giới thiệu" href="/about/">Giới thiệu</a>
                                    <ul>
                                        <li>
                                            <a title="Tiểu sử  Lê Quý Đôn" href="/about/">Tiểu sử  Lê Quý Đôn</a>
                                        </li>

                                        <li>
                                            <a title="Lịch Sử Phát Triển" href="/about/">Lịch Sử Phát Triển</a>
                                        </li>

                                        <li>
                                            <a title="Thành Tích Đạt Được" href="/about/">Thành Tích Đạt Được</a>
                                        </li>

                                    </ul>
                                </li>
                                <li class="current">
                                    <a title="Tin Tức" href="/">Tin Tức</a>
                                    <ul>
                                        <li>
                                            <a title="Tin Chi Bộ" href="/tin-chi-bo/">Tin Chi Bộ</a>
                                        </li>

                                        <li>
                                            <a title="tin nhà trường" href="/tin-cap-truong/">tin nhà trường</a>
                                        </li>

                                        <li>
                                            <a title="Tin Đoàn Thể" href="/tin-doan-the/">Tin Đoàn Thể</a>
                                        </li>

                                    </ul>
                                </li>
                                <li>
                                    <a title="Thời khóa biểu" href="http://ngnuong.byethost7.com/">Thời khóa biểu</a>
                                </li>
                                <li>
                                    <a title="Tổ chức" href="/to-chuc/">Tổ chức</a>
                                    <ul>
                                        <li>
                                            <a title="Ban Giám Hiệu" href="/to-chuc/">Ban Giám Hiệu</a>
                                        </li>

                                        <li>
                                            <a title="Công đoàn" href="/to-chuc/">Công đoàn</a>
                                        </li>

                                        <li>
                                            <a title="Đoàn thể" href="/to-chuc/">Đoàn thể</a>
                                        </li>

                                        <li>
                                            <a title="Tổ bộ môn" href="/to-chuc/">Tổ bộ môn</a>
                                        </li>

                                    </ul>
                                </li>
                                <li>
                                    <a title="TỔ BỘ MÔN" href="/tai-nguyen/">TỔ BỘ MÔN</a>
                                    <ul>
                                        <li>
                                            <a title="Tổ Toán -Tin" href="/mon-toan/">Tổ Toán -Tin</a>
                                        </li>

                                        <li>
                                            <a title="Môn Vật Lý" href="/mon-vat-ly/">Môn Vật Lý</a>
                                        </li>

                                        <li>
                                            <a title="Môn Hóa_Sinh" href="/mon-hoa-sinh/">Môn Hóa_Sinh</a>
                                        </li>

                                        <li>
                                            <a title="Môn Ngữ Văn" href="/mon-van/">Môn Ngữ Văn</a>
                                        </li>

                                        <li>
                                            <a title="Tổ Sử Công Dân" href="/mon-su-cong-dan/">Tổ Sử Công Dân</a>
                                        </li>

                                        <li>
                                            <a title="Môn địa" href="/mon-dia/">Môn địa</a>
                                        </li>

                                        <li>
                                            <a title="Tổ Ngoại Ngữ" href="/ngoai-ngu/">Tổ Ngoại Ngữ</a>
                                        </li>

                                        <li>
                                            <a title="Thể dục_QPAN" href="/the-duc-qpan/">Thể dục_QPAN</a>
                                        </li>

                                        <li>
                                            <a title="Văn Phòng" href="/van-phong/">Văn Phòng</a>
                                        </li>

                                    </ul>
                                </li>
                                <li>
                                    <a title="Kế Hoạch" href="/page/">Kế Hoạch</a>
                                    <ul>
                                        <li>
                                            <a title="Kế hoạch Chi bộ" href="/kh-chi-bo/">Kế hoạch Chi bộ</a>
                                        </li>

                                        <li>
                                            <a title="Kế hoạch BGH" href="/ke-hoach-nha-truong/">Kế hoạch BGH</a>
                                            <ul>
                                                <li>
                                                    <a title="Kế hoạch nhà trường" href="/ke-hoach-nha-truong/">Kế hoạch nhà trường</a>
                                                </li>

                                                <li>
                                                    <a title="Kế hoạch_Huỳnh văn Thông" href="/khhuynhthong/">Kế hoạch_Huỳnh văn Thông</a>
                                                </li>

                                                <li>
                                                    <a title="Kê hoạch_Nguyễn Đức Tính" href="/khductinh/">Kê hoạch_Nguyễn Đức Tính</a>
                                                </li>

                                            </ul>
                                        </li>

                                        <li>
                                            <a title="Kế hoạch Công đoàn" href="/kh-cong-doan/">Kế hoạch Công đoàn</a>
                                        </li>

                                        <li>
                                            <a title="Kế hoạch Đoàn TN" href="/tin-doan-the/">Kế hoạch Đoàn TN</a>
                                        </li>

                                    </ul>
                                </li>
                                <li>
                                    <a title="Tuyển sinh" href="/tuyen-sinh/">Tuyển sinh</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>
            <nav class="header-nav">
                <div class="container">
                    <div class="menu_topbar">
                        <a href="javascript:void(0);">
                            <em class="fa fa-th-list"></em>
                        </a>
                    </div>
                    <div class="contactDefault  col-xs-8 col-sm-14 col-md-12">
                    </div>
                    <div class="personalArea  col-xs-6 col-sm-5 col-md-5">
                        <div class="headerSearch">
                            <div class="input-group">
                                <input type="text" class="form-control" maxlength="60" placeholder="Tìm kiếm...">
                                <span class="input-group-btn"><button type="button" class="btn btn-info" data-url="/seek/?q=" data-minlength="3" data-click="y"><em class="fa fa-search fa-lg"></em></button></span>
                            </div>
                        </div>
                    </div>
                    <div class="social-icons col-xs-13 col-sm-9 col-md-7">
                        <div class="icon_user fr"><a href="javascript:void(0);"><em class="fa fa-user-secret"></em></a>
                        </div>
                        <div id="nv-block-login" class="text-right">
                            <a href="javascript:void(0);" class="login" onclick="modalShowByObj('#guestLogin_nv5', 'recaptchareset')">
	Đăng nhập
</a>
                            <i>&#47;</i>

                            <a href="javascript:void(0);" class="register" onclick="modalShowByObj('#guestReg_nv5', 'recaptchareset')">
	Đăng ký
</a>

                        </div>
                    </div>
                    <div id="tip" data-content="">
                        <div class="bg"></div>
                    </div>
                </div>
            </nav>
            <section>
                <div class="container" id="body">
                    
                    
                    
                    
                    <div class="row">
                        <div class="col-sm-16 col-md-18">

                            <div style="height: 20px"></div>
                            <div>
                                <button class="btn btn-primary" style="height: 40px;width: 110px;" onclick="history.back();"><i class="fas fa-arrow-left"></i></button>
                            </div>
                            <div style="height: 20px"></div>

                            <?php switch($k):

                            case ("tinnhanh"): ?>
                                <div>
                                    <div style="width: 100% ;border: slategrey solid 1px; text-align: left; ">
                                    <div><h1 style="text-align: center; padding-bottom: 20px; font-size: 32px; "><?php echo e($tieude); ?></h1></div>
                                    <div style="margin-left: 95%; height: 30px;">
                                        <a href="../../../../public/tinnhanh/<?php echo e($vanban); ?>"  class="dimgray" title="Lưu bài viết này">
                                            <em class="fa fa-save fa-lg" >&nbsp;</em>
                                        </a> 
                                    </div>
                                    <div style="margin-left: 5%">
                                        <?php include '../public/tinnhanh/'.$vanban.'.html'?>
                                    </div>
                                    </div>
                                </div>
                            <?php break; ?>

                            <?php case ("vbmoi"): ?>
                                <div>
                                    <div style="width: 100% ;border: slategrey solid 1px; text-align: left; ">
                                    <div><h1 style="text-align: center; padding-bottom: 20px; font-size: 32px; "><?php echo e($tieude); ?></h1></div>
                                    <div style="margin-left: 95%; height: 30px;">
                                        <a href="../../../../public/vanbanmoi/<?php echo e($vanban); ?>"  class="dimgray" title="Lưu bài viết này">
                                            <em class="fa fa-save fa-lg" >&nbsp;</em>
                                        </a> 
                                    </div>
                                    <div style="margin-left: 5%">
                                        <?php include '../public/vanbanmoi/'.$vanban.'.html'?>
                                    </div>
                                    </div>
                                </div>
                            <?php break; ?>

                            <?php case ("tinmoinhat"): ?>
                                <div>
                                    <div style="width: 100% ;border: slategrey solid 1px; text-align: left; ">
                                    <div><h1 style="text-align: center; padding-bottom: 20px; font-size: 32px; "><?php echo e($tieude); ?></h1></div>
                                    <div style="margin-left: 95%; height: 30px;">
                                        <a href="../../../../public/tinmoinhat/vanban/<?php echo e($vanban); ?>"  class="dimgray" title="Lưu bài viết này">
                                            <em class="fa fa-save fa-lg" >&nbsp;</em>
                                        </a> 
                                    </div>
                                    <div style="margin-left: 5%">
                                        <?php include '../public/tinmoinhat/vanban/'.$vanban.'.html'?>
                                    </div>
                                    </div>
                                </div>
                            <?php break; ?>

                            <?php case ("vanbantruong"): ?>
                                <div>
                                    <div style="width: 100% ;border: slategrey solid 1px; text-align: left; ">
                                    <div><h1 style="text-align: center; padding-bottom: 20px; font-size: 32px; "><?php echo e($tieude); ?></h1></div>
                                    <div style="margin-left: 95%; height: 30px;">
                                        <a href="../../../../public/vanbantruong/<?php echo e($vanban); ?>"  class="dimgray" title="Lưu bài viết này">
                                            <em class="fa fa-save fa-lg" >&nbsp;</em>
                                        </a> 
                                    </div>
                                    <div style="margin-left: 5%">
                                        <?php include '../public/vanbantruong/'.$vanban.'.html'?>
                                    </div>
                                    </div>
                                </div>
                            <?php break; ?>

                            <?php case ("vanbanso"): ?>
                                <div>
                                    <div style="width: 100% ;border: slategrey solid 1px; text-align: left; ">
                                    <div><h1 style="text-align: center; padding-bottom: 20px; font-size: 32px; "><?php echo e($tieude); ?></h1></div>
                                    <div style="margin-left: 95%; height: 30px;">
                                        <a href="../../../../public/vanbancapso/<?php echo e($vanban); ?>"  class="dimgray" title="Lưu bài viết này">
                                            <em class="fa fa-save fa-lg" >&nbsp;</em>
                                        </a> 
                                    </div>
                                    <div style="margin-left: 5%">
                                        <?php include '../public/vanbancapso/'.$vanban.'.html'?>
                                    </div>
                                    </div>
                                </div>
                            <?php break; ?>

                            <?php case ("tinnhatruong"): ?>
                                <div>
                                    <div style="width: 100% ;border: slategrey solid 1px; text-align: left; ">
                                    <div><h1 style="text-align: center; padding-bottom: 20px; font-size: 32px; "><?php echo e($tieude); ?></h1></div>
                                    <div style="margin-left: 95%; height: 30px;">
                                        <a href="../../../../public/tinnhatruong/vanban/<?php echo e($vanban); ?>"  class="dimgray" title="Lưu bài viết này">
                                            <em class="fa fa-save fa-lg" >&nbsp;</em>
                                        </a> 
                                    </div>
                                    <div style="margin-left: 5%">
                                        <?php include '../public/tinnhatruong/vanban/'.$vanban.'.html'?>
                                    </div>
                                    </div>
                                </div>
                            <?php break; ?>

                            <?php case ("congdoan"): ?>
                                <div>
                                    <div style="width: 100% ;border: slategrey solid 1px; text-align: left; ">
                                    <div><h1 style="text-align: center; padding-bottom: 20px; font-size: 32px; "><?php echo e($tieude); ?></h1></div>
                                    <div style="margin-left: 95%; height: 30px;">
                                        <a href="../../../../public/congdoan/vanban/<?php echo e($vanban); ?>"  class="dimgray" title="Lưu bài viết này">
                                            <em class="fa fa-save fa-lg" >&nbsp;</em>
                                        </a> 
                                    </div>
                                    <div style="margin-left: 5%;">
                                        <?php include '../public/congdoan/vanban/'.$vanban.'.html'?>
                                    </div>
                                    </div>
                                </div>
                            <?php break; ?>

                            <?php case ("tindoanthe"): ?>
                                <div>
                                    <div style="width: 100% ;border: slategrey solid 1px; text-align: left; ">
                                    <div><h1 style="text-align: center; padding-bottom: 20px; font-size: 32px; "><?php echo e($tieude); ?></h1></div>
                                    <div style="margin-left: 95%; height: 30px;">
                                        <a href="../../../../public/tindoanthe/vanban/<?php echo e($vanban); ?>"  class="dimgray" title="Lưu bài viết này">
                                            <em class="fa fa-save fa-lg" >&nbsp;</em>
                                        </a> 
                                    </div>
                                    <div style="margin-left: 5%">
                                        <?php include '../public/congdoan/vanban/'.$vanban.'.html'?>
                                    </div>
                                    </div>
                                </div>
                            <?php break; ?>

                            <?php case ("hdngoaigiolenlop"): ?>
                                <div>
                                    <div style="width: 100% ;border: slategrey solid 1px; text-align: left; ">
                                    <div><h1 style="text-align: center; padding-bottom: 20px; font-size: 32px; "><?php echo e($tieude); ?></h1></div>
                                    <div style="margin-left: 95%; height: 30px;">
                                        <a href="../../../../public/hdngoaigiolenlop/vanban/<?php echo e($vanban); ?>"  class="dimgray" title="Lưu bài viết này">
                                            <em class="fa fa-save fa-lg" >&nbsp;</em>
                                        </a> 
                                    </div>
                                    <div style="margin-left: 5%">
                                        <?php include '../public/hdngoaigiolenlop/vanban/'.$vanban.'.html'?>
                                    </div>
                                    </div>
                                </div>
                            <?php break; ?>

                            
                        <?php endswitch; ?>
                            

                        </div>
                        <div class="col-sm-8 col-md-6">
                            <div class="panel panel-white">
                                <div class="panel-heading">
                                    VIDEO
                                </div>
                                <div class="panel-body">
                                    <ul class="videotop" id="blvideo_bl145">
                                        <li class="clearfix">
                                            <div class="videoplayer_bl" id="videoContCtn_bl145_v8">
                                                <div class="cont">
                                                    <div id="videoCont_bl145_v8"></div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>

                                </div>
                            </div>

                            <div class="panel panel-white margin-bottom">
                                <div class="nv-block-banners">
                                    <img alt="Bộ giáo dục và đào tạo" src="/uploads/thptlequydon/banners/logobgd.gif" width="300">
                                </div>
                                <div class="nv-block-banners">
                                    <img alt="Mas" src="/uploads/thptlequydon/banners/24-12-2014-10-32-31-am.png" width="300">
                                </div>
                                <div class="nv-block-banners">
                                    <img alt="Vnedu" src="/uploads/thptlequydon/banners/edunet_1.png" width="300">
                                </div>
                                <div class="nv-block-banners">
                                    <img alt="Phần mềm quản lý" src="/uploads/thptlequydon/banners/emisonline.png" width="300">
                                </div>
                            </div>

                            <div class="panel panel-white">
                                <div class="panel-heading">
                                    Thư viện ảnh
                                </div>
                                <div class="panel-body">
                                    <ul class="list_album">
                                        <li class="text-center">
                                            <a href="/albums/xem-album/ANH-CHI-BO-16/" title="ẢNH CHI BỘ">
                                                <img src="/uploads/thptlequydon/albums/albums_cache/be4449d57a4c9d12c45d_bf4769b0762190a6e99e9e3ae86a11f2.jpg" class="img-thumbnail" alt="ẢNH CHI BỘ" width="105" height="63" />
                                            </a>
                                            <a href="/albums/xem-album/ANH-CHI-BO-16/" title="ẢNH CHI BỘ">ẢNH CHI BỘ</a>
                                        </li>
                                        <li class="text-center">
                                            <a href="/albums/xem-album/ANH-TRUONG-2/" title="ẢNH TRƯỜNG">
                                                <img src="/uploads/thptlequydon/albums/albums_cache/dsc_0002_33d8bfdde5853849af76dec8aa889c9b.jpg" class="img-thumbnail" alt="ẢNH TRƯỜNG" width="105" height="70" />
                                            </a>
                                            <a href="/albums/xem-album/ANH-TRUONG-2/" title="ẢNH TRƯỜNG">ẢNH TRƯỜNG</a>
                                        </li>
                                        <li class="text-center">
                                            <a href="/albums/xem-album/TO-VAN-PHONG-15/" title="TỔ VĂN PHÒNG">
                                                <img src="/uploads/thptlequydon/albums/albums_cache/be4449d57a4c9d12c45d_bf4769b0762190a6e99e9e3ae86a11f2.jpg" class="img-thumbnail" alt="TỔ VĂN PHÒNG" width="105" height="63" />
                                            </a>
                                            <a href="/albums/xem-album/TO-VAN-PHONG-15/" title="TỔ VĂN PHÒNG">TỔ VĂN PHÒNG</a>
                                        </li>
                                        <li class="text-center">
                                            <a href="/albums/xem-album/TO-TOAN-14/" title="TỔ TOÁN">
                                                <img src="/uploads/thptlequydon/albums/albums_cache/f370e686c21f25417c0e_cfbb36cc89cbbad52e5208f3d7bc79e4.jpg" class="img-thumbnail" alt="TỔ TOÁN" width="105" height="70" />
                                            </a>
                                            <a href="/albums/xem-album/TO-TOAN-14/" title="TỔ TOÁN">TỔ TOÁN</a>
                                        </li>
                                        <li class="text-center">
                                            <a href="/albums/xem-album/TO-TIN-11/" title="TỔ TIN">
                                                <img src="/uploads/thptlequydon/albums/albums_cache/79c9a4a35a3dbd63e42c_032ebca5ee9137f23ff3b5582c6d10dd.jpg" class="img-thumbnail" alt="TỔ TIN" width="105" height="70" />
                                            </a>
                                            <a href="/albums/xem-album/TO-TIN-11/" title="TỔ TIN">TỔ TIN</a>
                                        </li>
                                        <li class="text-center">
                                            <a href="/albums/xem-album/TO-LY-4/" title="TỔ LÝ">
                                                <img src="/uploads/thptlequydon/albums/albums_cache/10425462_665386276913728_3628273835736875950_n_a216adad5ef10844a69637d81573ea49.jpg" class="img-thumbnail" alt="TỔ LÝ" width="105" height="70" />
                                            </a>
                                            <a href="/albums/xem-album/TO-LY-4/" title="TỔ LÝ">TỔ LÝ</a>
                                        </li>
                                        <li class="text-center">
                                            <a href="/albums/xem-album/TO-HOA-SINH-7/" title="TỔ HÓA - SINH">
                                                <img src="/uploads/thptlequydon/albums/albums_cache/h_b256ae6c9d22286bfa87560ae90f4410.jpg" class="img-thumbnail" alt="TỔ HÓA - SINH" width="105" height="70" />
                                            </a>
                                            <a href="/albums/xem-album/TO-HOA-SINH-7/" title="TỔ HÓA - SINH">TỔ HÓA - SINH</a>
                                        </li>
                                        <li class="text-center">
                                            <a href="/albums/xem-album/TO-VAN-5/" title="TỔ VĂN">
                                                <img src="/uploads/thptlequydon/albums/albums_cache/v_d7cfc4caeeacafa85f0c11cd394559f6.jpg" class="img-thumbnail" alt="TỔ VĂN" width="105" height="70" />
                                            </a>
                                            <a href="/albums/xem-album/TO-VAN-5/" title="TỔ VĂN">TỔ VĂN</a>
                                        </li>
                                        <li class="text-center">
                                            <a href="/albums/xem-album/TO-SU-CONG-DAN-12/" title="TỔ SỬ- CÔNG DÂN">
                                                <img src="/uploads/thptlequydon/albums/albums_cache/hinh-dai-dien-cua-to_726518bac96a3fc0fb90cbdf5a0f7dc6.jpg" class="img-thumbnail" alt="TỔ SỬ- CÔNG DÂN" width="105" height="53" />
                                            </a>
                                            <a href="/albums/xem-album/TO-SU-CONG-DAN-12/" title="TỔ SỬ- CÔNG DÂN">TỔ SỬ- CÔNG DÂN</a>
                                        </li>
                                        <li class="text-center">
                                            <a href="/albums/xem-album/TO-NGOAI-NGU-10/" title="TỔ NGOẠI NGỮ">
                                                <img src="/uploads/thptlequydon/albums/albums_cache/bad3ac1983fc65a23ced_c3081ddff8e0a8f03bcc04d7af81e4df.jpg" class="img-thumbnail" alt="TỔ NGOẠI NGỮ" width="105" height="69" />
                                            </a>
                                            <a href="/albums/xem-album/TO-NGOAI-NGU-10/" title="TỔ NGOẠI NGỮ">TỔ NGOẠI NGỮ</a>
                                        </li>
                                        <li class="text-center">
                                            <a href="/albums/xem-album/TO-DIA-8/" title="TỔ ĐỊA">
                                                <img src="/uploads/thptlequydon/albums/albums_cache/d_f3e598124f624ff254f281caf5c050c3.jpg" class="img-thumbnail" alt="TỔ ĐỊA" width="105" height="60" />
                                            </a>
                                            <a href="/albums/xem-album/TO-DIA-8/" title="TỔ ĐỊA">TỔ ĐỊA</a>
                                        </li>
                                        <li class="text-center">
                                            <a href="/albums/xem-album/TO-THE-DUC-QP-13/" title="TỔ THỂ DUC- QP">
                                                <img src="/uploads/thptlequydon/albums/albums_cache/td1_beeba2a27aaabb4bd4aa84314af9da51.jpg" class="img-thumbnail" alt="TỔ THỂ DUC- QP" width="105" height="70" />
                                            </a>
                                            <a href="/albums/xem-album/TO-THE-DUC-QP-13/" title="TỔ THỂ DUC- QP">TỔ THỂ DUC- QP</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                    

                        </div>
                    </div>
                   
                </div>
            </section>
        </div>
        <footer id="footer">
            <div class="wraper">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-24 col-sm-24 col-md-16">
                            <span style="color:rgb(231, 76, 60);"><strong>Bản quyền thuộc về trường THPT Vân Hội<br />Địa chỉ: Thôn 8, Xã Vân Hội, Huyện Trấn Yên, Yên Bái<br />Chịu trách nhiệm nội dung: Bà Trần Thị Hồng Tuyến - Bí thư Chi bộ, Hiệu trưởng Nhà trường.</strong></span>

                        </div>
                        
                    </div>
                </div>
            </div>
        </footer>
        <nav class="footerNav2">
            <div class="wraper">
                <div class="container">
                    <div class="theme-change">
                        <span title="Chế độ giao diện đang hiển thị: Tự động"><em class="fa fa-random fa-lg"></em></span>
                        <a href="/?nvvithemever=d&amp;nv_redirect=AdmWY8Fa2CNZsUxY4CrqYOn9qg0uK0-q0IhoPSx7bSU%2C" title="Click để chuyển sang giao diện Máy Tính"><em class="fa fa-desktop fa-lg"></em></a>
                    </div>
                    <div class="bttop">
                        <a class="pointer"><em class="fa fa-eject fa-lg"></em></a>
                    </div>
                </div>
            </div>
        </nav>
    </div>
    <!-- SiteModal Required!!! -->
    <div id="sitemodal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <em class="fa fa-spinner fa-spin">&nbsp;</em>
                </div>
                <button type="button" class="close" data-dismiss="modal"><span class="fa fa-times"></span>
                </button>
            </div>
        </div>
    </div>
    <div class="fix_banner_left">
    </div>
    <div class="fix_banner_right">
    </div>
    <div id="timeoutsess" class="chromeframe">
        Bạn đã không sử dụng Site, <a onclick="timeoutsesscancel();" href="#">Bấm vào đây để duy trì trạng thái đăng nhập</a>. Thời gian chờ: <span id="secField"> 60 </span> giây
    </div>
    <div id="openidResult" class="nv-alert" style="display:none"></div>
    <div id="openidBt" data-result="" data-redirect=""></div>
    <div id="run_cronjobs" style="visibility:hidden;display:none;"><img alt="" src="/index.php?second=cronjobs&amp;p=g2A1n20L" width="1" height="1" />
    </div>

    <div id="guestLogin_nv5" class="hidden">
        <div class="page panel panel-default bg-lavender box-shadow">
            <div class="panel-body">
                <h2 class="text-center margin-bottom-lg">
			Thành viên đăng nhập
		</h2>
                <form autocomplete="off" novalidate method="POST" action="<?php echo e(route('login')); ?>">
                    
                   
                    <?php echo e(csrf_field()); ?>

                    <div class="form-detail">
                        <div class="form-group loginstep1">
                            <div class="input-group">
                                <span class="input-group-addon"><em class="fa fa-user fa-lg"></em></span>
                                <input type="text" id="usernamelg" class="required form-control" placeholder="Tên đăng nhập " value="" name="usernamelg" maxlength="100" >
                            </div>
                        </div>

                        <div class="form-group loginstep1">
                            <div class="input-group">
                                <span class="input-group-addon"><em class="fa fa-key fa-lg fa-fix"></em></span>
                                <input type="password" id="passwordlg" autocomplete="off" class="required form-control" placeholder="Mật khẩu" value="" name="passwordlg" maxlength="100" >
                            </div>
                        </div>
                       
                        <div class="text-center margin-bottom-lg">
                            
                            <button class="bsubmit btn btn-primary" type="submit">Đăng nhập</button>
                        </div>
                        <div class="text-center margin-bottom-lg" id="thongbao" style="color: red"></div>
                        
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div id="guestReg_nv5" class="hidden">
        <div class="page panel panel-default bg-lavender box-shadow">
            <div class="panel-body">
                <h2 class="text-center margin-bottom-lg">
			Đăng ký thành viên
		</h2>
                <div  autocomplete="off" novalidate>
                    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" id="token">
                    <div class="nv-info margin-bottom" data-default="Để đăng ký thành viên, bạn cần khai báo tất cả các ô trống dưới đây">Để đăng ký thành viên, bạn cần khai báo tất cả các ô trống dưới đây</div>

                    <div class="form-detail">
                        <div class="form-group">
                            <div>
                                <input type="text" class="required form-control" placeholder="Tên đăng nhập"  id="username" name="username" maxlength="20" data-pattern="/^(.){4,20}$/" onkeypress="validErrorHidden(this);" data-mess="Tên đăng nhập không hợp lệ: Tên đăng nhập chỉ được sử dụng chữ số và chữ cái và có từ 4 đến 20 ký tự">
                            </div>
                        </div>

                        <div class="form-group">
                            <div>
                               
                                <input type="email" class="required form-control" placeholder="Email"  id="email" name="email" maxlength="100" >
                            </div>
                        </div>

                        <div class="form-group">
                            <div>
                                <input type="password" autocomplete="off" class="password required form-control" id="password" placeholder="Mật khẩu"  name="password" maxlength="30" data-pattern="/^(.){5,20}$/" onkeypress="validErrorHidden(this);" data-mess="Mật khẩu không hợp lệ: Mật khẩu cần kết hợp số và chữ và có từ 5 đến 20 ký tự">
                            </div>
                        </div>

                        <div class="form-group">
                            <div>
                                <input type="password" autocomplete="off" class="password required form-control" id="confimpassword" placeholder="Mật khẩu"  name="confimpassword" maxlength="30" data-pattern="/^(.){5,20}$/" onkeypress="validErrorHidden(this);" data-mess="Mật khẩu không hợp lệ: Mật khẩu cần kết hợp số và chữ và có từ 5 đến 20 ký tự">
                            </div>
                        </div> 

                        <div class="text-center margin-bottom-lg">
                            <input type="submit" class="btn btn-primary" value="Đăng ký thành viên" id="btnsubmit" onclick="dangky()" />
                        </div>

                        <div class="text-center margin-bottom-lg" id="thongbao" style="color: red" ></div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('js/jquery.min.js?t=1614914252')); ?>"></script>
    
    
    <script>
    function dangky()
    {
        $(document).ready(function() {    
           
                    $.ajaxSetup({
                    headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                    });
                    
                    var _token = $("#token").val();
                    var username = $("#username").val().trim();
                    var password = $("#password").val().trim();
                    var confimpassword = $("#confimpassword").val().trim();
                    var email = $("#email").val().trim();
                    
                    if(username.length ==0)
                    {
                        showError('Vui lòng nhập tên đăng nhập')
                    }
                    else if (username.length <3 || username.length >30)
                    {
                        showError('Vui lòng nhập tên đăng nhập lớn hơn 3 và nhỏ hơn 30 ký tự')
                    }
                    else if(email.length == 0)
                    {
                        showError('Vui lòng nhập email')
                    }
                    else if(!email.includes('@'))
                    {
                        showError('Địa chỉ email không hợp  lệ')
                    }
                    else if (password.length == 0)
                    {
                        showError('Vui lòng nhập mật khẩu')
                    }
                    else if(password.length <8 || password.length >100)
                    {
                        showError('Vui lòng nhập mật khẩu lớn hơn 8 nhỏ hơn 100 ký tự')
                    }
                    else if(password != confimpassword)
                    {
                        showError('Mật khẩu nhập lại không khớp! Vui lòng nhập lại')
                    }
                   
                    else
                    {
                        $.ajax({
                            
                            url: "<?php echo e(route('dangky')); ?>",
                            type:'POST',
                            data: {_token:_token, username:username, password:password, email:email},
                            success:function(data){ //dữ liệu nhận về
                            $('#thongbao').show();  
                            $('#thongbao').html(data);}
                        }); 
                    }    
            });
    }


    
        
    function showError(message){
        $('#thongbao').html(message)
        $('#thongbao').show()
    }
    </script>

    <script>
        var nv_base_siteurl = "/",
            nv_lang_data = "vi",
            nv_lang_interface = "vi",
            nv_name_variable = "nv",
            nv_fc_variable = "op",
            nv_lang_variable = "language",
            nv_module_name = "news",
            nv_func_name = "main",
            nv_is_user = 0,
            nv_my_ofs = 7,
            nv_my_abbr = "+07",
            nv_cookie_prefix = "nv4c_Cgoz2",
            nv_check_pass_mstime = 1738000,
            nv_area_admin = 0,
            nv_safemode = 0,
            theme_responsive = 1,
            nv_is_recaptcha = 1,
            nv_recaptcha_sitekey = "6LcNwC8UAAAAAMm8ZTYNygweLUQtOU0IapbDRk69",
            nv_recaptcha_type = "image",
            nv_recaptcha_elements = [];
    </script>
    <script src="<?php echo e(asset('js/vi.js?t=1614914252')); ?>"></script>
    <script src="<?php echo e(asset('js/global.js?t=1614914252')); ?>"></script>
    <script src="<?php echo e(asset('js/news.js?t=1614914252')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js?t=1614914252')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery.imgpreload.min.js?t=1614914252')); ?>"></script>
    <script type="text/javascript">
        function nv_update_picture_views(id, viewed) {
            if (id > 0) {
                $.post(script_name + '?' + nv_name_variable + '=' + nv_module_name + '&' + nv_fc_variable + '=albums&nocache=' + new Date().getTime(), 'updatepicview=1&viewed=' + viewed + '&id=' + id + '&num=' + nv_randomPassword(8), 'viewed' + id, function(res) {});
            }
            return false;
        }
        $(document).ready(function() {
            $('[rel="modalimg"]').click(function(e) {
                e.preventDefault();
                var a, b;

                a = $(this).attr('title');
                b = '<img src="' + $(this).attr('href') + '" style="width:100%">';
                modalShow(a, b);
            });

        });
    </script>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery.slimmenu.js?t=1614914252')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery-ui.min.js?t=1614914252')); ?>"></script>
    <script type="text/javascript">
        $('ul.slimmenu').slimmenu({
            resizeWidth: (theme_responsive == '1') ? 768 : 0,
            collapserTitle: '',
            easingEffect: 'easeInOutQuint',
            animSpeed: 'medium',
            indentChildren: true,
            childrenIndenter: '&nbsp;&nbsp; '
        });
    </script>
    <script type="text/javascript">
        $(".icon_user a").click(function() {
            $("#nv-block-login").slideToggle("slow");
        });
    </script>
    <script src="<?php echo e(asset('js/users.js?t=1614914252')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery.breakingnews.js?t=1614914252')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $(".breakingNews").breakingNews({
                effect: "slide-h",
                autoplay: true,
                timer: 3000,
                color: "yellow"
            });

        });
    </script>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery.marquee.min.js?t=1614914252')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#marquee-b141').marquee({
                duration: 2000 * $('#marquee-b141 li').length,
                gap: 10,
                duplicated: true,
                direction: 'up',
                startVisible: true
            });
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            $("[data-rel='block_tooltip'][data-content!='']").tooltip({
                placement: "bottom",
                html: true,
                title: function() {
                    return ($(this).data('img') == '' ? '' : '<img class="img-thumbnail pull-left margin_image" src="' + $(this).data('img') + '" width="90" />') + '<p class="text-justify">' + $(this).data('content') + '</p><div class="clearfix"></div>';
                }
            });
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            $("[data-rel='block_tooltip'][data-content!='']").tooltip({
                placement: "bottom",
                html: true,
                title: function() {
                    return ($(this).data('img') == '' ? '' : '<img class="img-thumbnail pull-left margin_image" src="' + $(this).data('img') + '" width="90" />') + '<p class="text-justify">' + $(this).data('content') + '</p><div class="clearfix"></div>';
                }
            });
        });
    </script>
    <script type="text/javascript" src="<?php echo e(asset('js/jwplayer.js?t=1614914252')); ?>"></script>
    <script type="text/javascript">
        jwplayer.key = "KzcW0VrDegOG/Vl8Wb9X3JLUql+72MdP1coaag==";
    </script>
    <script type="text/javascript">
        $(function() {
            var ele = "videoCont_bl145_v8";
            var a = $("#videoContCtn_bl145_v8").outerWidth(),
                b;
            640 < a && (a = 640);
            b = a;
            a = Math.ceil(45 * a / 80) + 4;
            $("#" + ele).parent().css({
                width: b,
                height: a,
                margin: "0 auto"
            });
            jwplayer(ele).setup({
                file: "/uploads/thptlequydon/.mp4",
                width: b,
                height: a,
                autostart: false
            });
        });
    </script>
    <script src="<?php echo e(asset('js/bootstrap.min.js?t=1614914252')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/contentslider.js?t=1614914252')); ?>"></script>
    <script type="text/javascript">
        //<![CDATA[
        $(document).ready(function() {
            var b = ["/uploads/thptlequydon/news/hanh.jpg", "/uploads/thptlequydon/news/image-20210225163055-1.jpeg", "/uploads/thptlequydon/news/image-20210118140701-2.jpeg"];
            $.imgpreload(b, function() {
                for (var c = b.length, a = 0; a < c; a++) $("#slImg" + a).attr("src", b[a]);
                featuredcontentslider.init({
                    id: "slider1",
                    contentsource: ["inline", ""],
                    toc: "#increment",
                    nextprev: ["&nbsp;", "&nbsp;"],
                    revealtype: "click",
                    enablefade: [true, 0.2],
                    autorotate: [true, 3E3],
                    onChange: function() {}
                });
                $("#tabs").tabs({
                    ajaxOptions: {
                        error: function(e, f, g, d) {
                            $(d.hash).html("Couldnt load this tab.")
                        }
                    }
                });
                $("#topnews").show()
            })
        });
        //]]>
    </script>


	
	
</body>

</html><?php /**PATH C:\xampp\htdocs\thptvanhoi\resources\views/vanban.blade.php ENDPATH**/ ?>