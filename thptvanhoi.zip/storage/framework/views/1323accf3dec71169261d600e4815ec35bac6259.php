
<?php $__env->startSection('NoiDung'); ?>
<div class="container-fluid">
    <div style="padding-left: 35%;padding-top: 3%">
        <h2 >Tạo tài khoản Học Sinh</h2>
    </div>
    <div  style="padding-left: 32%;">
        <table>
        <tr style="height: 45px">
            <td> <input type="text" placeholder="Tên đăng nhập"></td>
            <td  style="padding-left: 5%;"><input type="text" placeholder="Họ và tên giáo viên"></td>
        </tr>
        <tr style="height: 45px">
            <td><input type="text" placeholder="Gmail"></td>
            <td style="padding-left: 5%;"><input type="text" placeholder="Địa chỉ"></td>
        </tr>
        <tr style="height: 45px">
            <td><input type="text" placeholder="Số điện thoại"></td>
            <td style="padding-left: 5%;"><input type="text" placeholder="Ảnh"></td>
        </tr>
        <tr style="height: 45px">
            <th>Giới tính</th>
            <td  style="padding-left: 5%;">
                <input style="width: 30px;" type="radio" name="sex">Nam
                
                <input style="width: 30px;" type="radio" name="sex">Nữ
            </td>
        </tr>
        <tr style="height: 20px"></tr>
    </table> 
    <div style="padding-left: 10%"><button style="width: 25%;" class="btn btn-primary">Đăng Ký</button></div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Shop\resources\views/admin/addAccoutHS.blade.php ENDPATH**/ ?>