<!DOCTYPE html>
<html>
<head>
</head>
<body>


    <h1><?php echo e($details['title']); ?></h1>
    <p>Tài khoản đăng nhập nhà trường</p>
    <p>UserName <span style="color: red"><?php echo e($details['taikhoan']); ?></span></p>
    <p>Password <span style="color: red"><?php echo e($details['matkhau']); ?></span></p>
   

</body>
</html><?php /**PATH C:\xampp\htdocs\thptvanhoi\resources\views/email/testMail.blade.php ENDPATH**/ ?>