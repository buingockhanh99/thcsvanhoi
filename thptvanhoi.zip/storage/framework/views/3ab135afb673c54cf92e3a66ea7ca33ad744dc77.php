
<?php $__env->startSection('NoiDung'); ?>

<div class="container-fluid">
    <div style="padding-top: 3%;padding-bottom: 1%; text-align: center">
       <?php $tenchude = DB::table('chudeanh')->where('id',$key)->get(); ?>
       <?php $__currentLoopData = $tenchude; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tcd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h2>Quản lý ảnh <?php echo e($tcd->tenchude); ?> </h2>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php if(session('thongbao')): ?>
    <div class="alert alert-success" style="width: 500px; margin-left: 29%; text-align: center">
        <?php echo e(session('thongbao')); ?>

    </div>
    <?php endif; ?>
    <div><button class="btn btn-primary" style="width: 150px;"><i class="fas fa-plus"></i><a style="color: #fff" href="admin/themanh/<?php echo e($key); ?>"> Thêm ảnh</a></button></div>
    <div style="height: 30px;"></div>

    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
        <tr align="center">
            <th>STT</th>
            <th>Tiêu đề ảnh</th>
            <th>Ảnh</th>
            <th>Người đăng</th>
            <th>Xóa</th>
        </tr>
        <?php $i =1; ?>
         <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr class="odd gradeX" align="center" style="line-height: 200px" >
             <td><?php echo e($i++); ?></td>
             <td><?php echo e($dt->tenanh); ?></td>
             <td><img height="200px" width="200px" src="anhnhatruong/<?php echo e($dt->filename); ?>" alt=""></td>
             <?php $idnd =  DB::table('users')->where('name',$dt->nguoidang)->get() ?>
             <?php $__currentLoopData = $idnd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indnd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <td><a href="admin/thongtingv/<?php echo e($indnd->id); ?>"><?php echo e($dt->nguoidang); ?></a></td>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <td><a href="admin/xoaanh/<?php echo e($dt->id); ?>/<?php echo e($key); ?>"><i class="fas fa-trash-alt"></i></a></td>
         </tr>

        
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <div style="height: 30px;"></div>
   
  
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thptvanhoi\resources\views/admin/quanly/qlanh.blade.php ENDPATH**/ ?>