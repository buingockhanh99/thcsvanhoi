
<?php $__env->startSection('NoiDung'); ?>
            
    <div class="row">
        
        
        
        <div class="col-sm-18 col-md-18 " style="background: white;">

            <div style="width: 840px; height: 420px;">
                <style>
                        .carousel {
                        position: relative;
                    }
                    
                    .carousel-item {
                        position: relative;
                        display: none;
                        float: left;
                        width: 100%;
                        margin-right: -100%;
                        -webkit-backface-visibility: hidden;
                        backface-visibility: hidden;
                        transition: -webkit-transform 0.6s ease-in-out;
                        transition: transform 0.6s ease-in-out;
                        transition: transform 0.6s ease-in-out, -webkit-transform 0.6s ease-in-out;
                    }
                    
                    @media (prefers-reduced-motion: reduce) {
                        .carousel-item {
                            transition: none;
                        }
                    }
                    
                    .carousel-item.active,
                    .carousel-item-next,
                    .carousel-item-prev {
                        display: block;
                    }
                    
                    .carousel-item-next:not(.carousel-item-left),
                    .active.carousel-item-right {
                        -webkit-transform: translateX(100%);
                        transform: translateX(100%);
                    }
                    
                    .carousel-item-prev:not(.carousel-item-right),
                    .active.carousel-item-left {
                        -webkit-transform: translateX(-100%);
                        transform: translateX(-100%);
                    }
                    
                    .carousel-fade .carousel-item {
                        opacity: 0;
                        transition-property: opacity;
                        -webkit-transform: none;
                        transform: none;
                    }
                    
                    .carousel-fade .carousel-item.active,
                    .carousel-fade .carousel-item-next.carousel-item-left,
                    .carousel-fade .carousel-item-prev.carousel-item-right {
                        z-index: 1;
                        opacity: 1;
                    }
                    
                    .carousel-fade .active.carousel-item-left,
                    .carousel-fade .active.carousel-item-right {
                        z-index: 0;
                        opacity: 0;
                        transition: opacity 0s 0.6s;
                    }
                    
                    @media (prefers-reduced-motion: reduce) {
                        .carousel-fade .active.carousel-item-left,
                        .carousel-fade .active.carousel-item-right {
                            transition: none;
                        }
                    }
                    
                    .carousel-control-prev,
                    .carousel-control-next {
                        position: absolute;
                        top: 0;
                        bottom: 0;
                        z-index: 1;
                        display: -ms-flexbox;
                        display: flex;
                        -ms-flex-align: center;
                        align-items: center;
                        -ms-flex-pack: center;
                        justify-content: center;
                        width: 15%;
                        color: #fff;
                        text-align: center;
                        opacity: 0.5;
                        transition: opacity 0.15s ease;
                    }
                    
                    @media (prefers-reduced-motion: reduce) {
                        .carousel-control-prev,
                        .carousel-control-next {
                            transition: none;
                        }
                    }
                    
                    .carousel-control-prev:hover, .carousel-control-prev:focus,
                    .carousel-control-next:hover,
                    .carousel-control-next:focus {
                        color: #fff;
                        text-decoration: none;
                        outline: 0;
                        opacity: 0.9;
                    }
                    
                    .carousel-control-prev {
                        left: 0;
                    }
                    
                    .carousel-control-next {
                        right: 0;
                    }
                    
                    .carousel-control-prev-icon,
                    .carousel-control-next-icon {
                        display: inline-block;
                        width: 20px;
                        height: 20px;
                        background: no-repeat 50% / 100% 100%;
                    }
                    
                    .carousel-control-prev-icon {
                        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='%23fff' width='8' height='8' viewBox='0 0 8 8'%3e%3cpath d='M5.25 0l-4 4 4 4 1.5-1.5L4.25 4l2.5-2.5L5.25 0z'/%3e%3c/svg%3e");
                    }
                    
                    .carousel-control-next-icon {
                        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='%23fff' width='8' height='8' viewBox='0 0 8 8'%3e%3cpath d='M2.75 0l-1.5 1.5L3.75 4l-2.5 2.5L2.75 8l4-4-4-4z'/%3e%3c/svg%3e");
                    }
                    
                    .carousel-indicators {
                        position: absolute;
                        right: 0;
                        bottom: 0;
                        left: 0;
                        z-index: 15;
                        display: -ms-flexbox;
                        display: flex;
                        -ms-flex-pack: center;
                        justify-content: center;
                        padding-left: 0;
                        margin-right: 15%;
                        margin-left: 15%;
                        list-style: none;
                    }
                    
                    .carousel-indicators li {
                        box-sizing: content-box;
                        -ms-flex: 0 1 auto;
                        flex: 0 1 auto;
                        width: 30px;
                        height: 3px;
                        margin-right: 3px;
                        margin-left: 3px;
                        text-indent: -999px;
                        cursor: pointer;
                        background-color: #fff;
                        background-clip: padding-box;
                        border-top: 10px solid transparent;
                        border-bottom: 10px solid transparent;
                        opacity: .5;
                        transition: opacity 0.6s ease;
                    }
                    
                    @media (prefers-reduced-motion: reduce) {
                        .carousel-indicators li {
                            transition: none;
                        }
                    }
                    
                    .carousel-indicators .active {
                        opacity: 1;
                    }
                    
                    .carousel-caption {
                        position: absolute;
                        right: 15%;
                        bottom: 20px;
                        left: 15%;
                        z-index: 10;
                        padding-top: 20px;
                        padding-bottom: 20px;
                        color: #fff;
                        text-align: center;
                    }
                    
                    .custom-range:focus::-webkit-slider-thumb {
                        box-shadow: 0 0 0 1px #fff, 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
                    }
                    .custom-range::-webkit-slider-thumb {
                        width: 1rem;
                        height: 1rem;
                        margin-top: -0.25rem;
                        background-color: #007bff;
                        border: 0;
                        border-radius: 1rem;
                        -webkit-transition: background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
                        transition: background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
                        -webkit-appearance: none;
                        appearance: none;
                    }
                    
                    @media (prefers-reduced-motion: reduce) {
                        .custom-range::-webkit-slider-thumb {
                            -webkit-transition: none;
                            transition: none;
                        }
                    }
                    
                    .custom-range::-webkit-slider-thumb:active {
                        background-color: #b3d7ff;
                    }
                    
                    .custom-range::-webkit-slider-runnable-track {
                        width: 100%;
                        height: 0.5rem;
                        color: transparent;
                        cursor: pointer;
                        background-color: #dee2e6;
                        border-color: transparent;
                        border-radius: 1rem;
                    }
                    
                    
                    .custom-range:disabled::-webkit-slider-thumb {
                        background-color: #adb5bd;
                    }
                    
                    .custom-range:disabled::-webkit-slider-runnable-track {
                        cursor: default;
                    }
                    .carousel-indicators {
                        position: absolute;
                        right: 0;
                        bottom: 0;
                        left: 0;
                        z-index: 15;
                        display: -ms-flexbox;
                        display: flex;
                        -ms-flex-pack: center;
                        justify-content: center;
                        padding-left: 0;
                        margin-right: 15%;
                        margin-left: 15%;
                        list-style: none;
                    }
                    
                    .carousel-indicators li {
                        box-sizing: content-box;
                        -ms-flex: 0 1 auto;
                        flex: 0 1 auto;
                        width: 30px;
                        height: 3px;
                        margin-right: 3px;
                        margin-left: 3px;
                        text-indent: -999px;
                        cursor: pointer;
                        background-color: #fff;
                        background-clip: padding-box;
                        border-top: 10px solid transparent;
                        border-bottom: 10px solid transparent;
                        opacity: .5;
                        transition: opacity 0.6s ease;
                    }
                    
                    
                    @media (prefers-reduced-motion: reduce) {
                        .carousel-indicators li {
                            transition: none;
                        }
                    }
                    
                    .carousel-indicators .active {
                        opacity: 1;
                    }
                    
                    .carousel-inner {
                        position: relative;
                        width: 100%;
                        overflow: hidden;
                    }
                    
                    .carousel-inner::after {
                        display: block;
                        clear: both;
                        content: "";
                    }
                    
                    .carousel-item {
                        position: relative;
                        display: none;
                        float: left;
                        width: 100%;
                        margin-right: -100%;
                        -webkit-backface-visibility: hidden;
                        backface-visibility: hidden;
                        transition: -webkit-transform 0.6s ease-in-out;
                        transition: transform 0.6s ease-in-out;
                        transition: transform 0.6s ease-in-out, -webkit-transform 0.6s ease-in-out;
                    }
                    
                    @media (prefers-reduced-motion: reduce) {
                        .carousel-item {
                            transition: none;
                        }
                    }
                    
                    .carousel-item.active,
                    .carousel-item-next,
                    .carousel-item-prev {
                        display: block;
                    }
                    
                    .carousel-item-next:not(.carousel-item-left),
                    .active.carousel-item-right {
                        -webkit-transform: translateX(100%);
                        transform: translateX(100%);
                    }
                    
                    .carousel-item-prev:not(.carousel-item-right),
                    .active.carousel-item-left {
                        -webkit-transform: translateX(-100%);
                        transform: translateX(-100%);
                    }
                    
                    .carousel-fade .carousel-item {
                        opacity: 0;
                        transition-property: opacity;
                        -webkit-transform: none;
                        transform: none;
                    }
                    
                    .carousel-fade .carousel-item.active,
                    .carousel-fade .carousel-item-next.carousel-item-left,
                    .carousel-fade .carousel-item-prev.carousel-item-right {
                        z-index: 1;
                        opacity: 1;
                    }
                    
                    .carousel-fade .active.carousel-item-left,
                    .carousel-fade .active.carousel-item-right {
                        z-index: 0;
                        opacity: 0;
                        transition: opacity 0s 0.6s;
                    }
                    
                    @media (prefers-reduced-motion: reduce) {
                        .carousel-fade .active.carousel-item-left,
                        .carousel-fade .active.carousel-item-right {
                            transition: none;
                        }
                    }
                    
                    .d-block {
                        display: block !important;
                    }
                    
                    @media (min-width: 768px) {
                        .d-md-none {
                            display: none !important;
                        }
                        .d-md-inline {
                            display: inline !important;
                        }
                        .d-md-inline-block {
                            display: inline-block !important;
                        }
                        .d-md-block {
                            display: block !important;
                        }
                        .d-md-table {
                            display: table !important;
                        }
                        .d-md-table-row {
                            display: table-row !important;
                        }
                        .d-md-table-cell {
                            display: table-cell !important;
                        }
                        .d-md-flex {
                            display: -ms-flexbox !important;
                            display: flex !important;
                        }
                        .d-md-inline-flex {
                            display: -ms-inline-flexbox !important;
                            display: inline-flex !important;
                        }
                    }
                    .w-100 {
                        width: 100% !important;
                    }
                    .carousel-control-prev,
                    .carousel-control-next {
                        position: absolute;
                        top: 0;
                        bottom: 0;
                        z-index: 1;
                        display: -ms-flexbox;
                        display: flex;
                        -ms-flex-align: center;
                        align-items: center;
                        -ms-flex-pack: center;
                        justify-content: center;
                        width: 15%;
                        color: #fff;
                        text-align: center;
                        opacity: 0.5;
                        transition: opacity 0.15s ease;
                    }
                    
                    @media (prefers-reduced-motion: reduce) {
                        .carousel-control-prev,
                        .carousel-control-next {
                            transition: none;
                        }
                    }
                    
                    .carousel-control-prev:hover, .carousel-control-prev:focus,
                    .carousel-control-next:hover,
                    .carousel-control-next:focus {
                        color: #fff;
                        text-decoration: none;
                        outline: 0;
                        opacity: 0.9;
                    }
                    
                    .carousel-control-prev {
                        left: 0;
                    }
                    
                    .carousel-control-next {
                        right: 0;
                    }
                    
                    .carousel-control-prev-icon,
                    .carousel-control-next-icon {
                        display: inline-block;
                        width: 20px;
                        height: 20px;
                        background: no-repeat 50% / 100% 100%;
                    }
                    
                    .carousel-control-prev-icon {
                        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='%23fff' width='8' height='8' viewBox='0 0 8 8'%3e%3cpath d='M5.25 0l-4 4 4 4 1.5-1.5L4.25 4l2.5-2.5L5.25 0z'/%3e%3c/svg%3e");
                    }
                    
                    .carousel-control-next-icon {
                        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='%23fff' width='8' height='8' viewBox='0 0 8 8'%3e%3cpath d='M2.75 0l-1.5 1.5L3.75 4l-2.5 2.5L2.75 8l4-4-4-4z'/%3e%3c/svg%3e");
                    }
                </style>

                <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img style="width: 840px; height: 420px;" class="d-block w-100" src="<?php echo e(asset('images/khaigiang1.jpg')); ?>" alt="First slide">
                        <div class="carousel-caption d-none d-md-block">
                            <h1 style="color: #fff; font-size: 24px"> Khai giảng năm học mới</h1>
                        </div>
                    </div>
                    <?php $__currentLoopData = $tinmoinhat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tmn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="carousel-item">
                            <a href="vanban/tinmoinhat">
                            <img style="width: 840px; height: 420px;" class="d-block w-100" src="tinmoinhat/img/<?php echo e($tmn->imgname); ?>" alt="Second slide">
                            </a>
                            <div class="carousel-caption d-none d-md-block">
                                <a style="color: #fff; font-size: 24px" href="vanban/tinmoinhat"><h1><?php echo e($tmn->tieude); ?></h1></a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    
                    </a>
                </div>
            </div>


        </div>
        
        
        <div class="col-sm-6 col-md-6">
            
            <div class="panel panel-green">
                <div class="panel-heading">
                    Văn bản mới
                </div>
                <div class="panel-body" style="height: 385px">
                    <div id="marquee-b141" class="news-home-marquee">
                        <div class="clearfix">
                            <ul>
                                <?php $__currentLoopData = $vanbanmoi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vbm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="clearfix">
                                    <strong>
                                        <a  href="vanban/vbmoi/<?php echo e($vbm->tieude); ?>/<?php echo e($vbm->filename); ?>"><i class="fas fa-file-word"></i> <?php echo e($vbm->tieude); ?></a>
                                    </strong>
                                    <div class="text-muted"><small></small>
                                    </div>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        
    </div>
    
    
    <div class="row">
        <div class="col-sm-16 col-md-18">
            <div class="clearfix">
                
                <div class="col-xs-24 col-sm-12 col-md-12 left">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <span>Văn bản trường</span>
                        </div>
                        <div class="panel-body">
                            <ul>
                            <?php $__currentLoopData = $vanbantruong; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vbt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="clearfix">
                                    <div class="pull-left pubtime">
                                        <p>Th.<?php echo e($vbt->thang); ?></p>
                                        <p><?php echo e($vbt->ngay); ?></p>
                                    </div>
                                    <a class="show"  href="vanban/vanbantruong/<?php echo e($vbt->tieude); ?>/<?php echo e($vbt->filename); ?>" ><?php echo e($vbt->tieude); ?></a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>

                </div>
                
                <div class="col-xs-24 col-sm-12 col-md-12 right">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <span>Văn bản cấp sở</span>
                        </div>
                        <div class="panel-body">
                            <ul>
                                <?php $__currentLoopData = $vanbanso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vbs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="clearfix">
                                    <div class="pull-left pubtime">
                                        <p>Th.<?php echo e($vbs->thang); ?></p>
                                        <p><?php echo e($vbs->ngay); ?></p>
                                    </div>
                                    <a class="show" href="vanban/vanbanso/<?php echo e($vbs->tieude); ?>/<?php echo e($vbs->filename); ?>" data-content="" data-img="" data-rel="block_tooltip"><?php echo e($vbs->tieude); ?></a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>

                </div>
            </div>
            
            <div class="margin-bottom">
                <div class="nv-block-banners">
                    <img alt="Học tập và làm theo tấm gương đạo đức Hồ Chí Minh" src="images/baner_tam-guong-dao-duc_1.jpg" width="790">
                </div>

            </div>
            
            <div class="news_column">
                <div class="panel panel-default clearfix">
                    <div class="panel-heading">
                        <ul class="list-inline sub-list-icon" style="margin: 0">
                            <li style="width:200px; text-align: center">
                                <h4><span>Tin nhà trường</span></h4>
                            </li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-16 ">
                            <?php $__currentLoopData = $tinnhatruongnew; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tntn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a title="<?php echo e($tntn->tieude); ?>" href="vanban/tinnhatruong/<?php echo e($tntn->tieude); ?>/<?php echo e($tntn->filename); ?>"><img src="tinnhatruong/img/<?php echo e($tntn->imgname); ?>" alt="" style="width: 210px; height: 300px;"  class="img-thumbnail pull-left imghome" />
                                </a>
                                <h3>
                                    <a title="<?php echo e($tntn->tieude); ?>" href="vanban/tinnhatruong/<?php echo e($tntn->tieude); ?>/<?php echo e($tntn->filename); ?>" ><?php echo e($tntn->tieude); ?></a>
                                </h3>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                              
                            </div>
                            <div class="col-md-8  border-left-content">
                                <ul class="related">
                                    <?php $__currentLoopData = $tinnhatruong; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tnt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="icon_list">
                                        <a class="show h4" href="vanban/tinnhatruong/<?php echo e($tnt->tieude); ?>/<?php echo e($tnt->filename); ?>" title="<?php echo e($tnt->tieude); ?>" data-content="" data-img="tinnhatruong/vanban/<?php echo e($tnt->filename); ?>" data-rel="tooltip" data-placement="top"><?php echo e($tnt->tieude); ?></a>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="news_column">
                <div class="panel panel-default clearfix">
                    <div class="panel-heading">
                        <ul class="list-inline sub-list-icon" style="margin: 0">
                            <li style="width:200px; text-align: center">
                                <h4><span>CÔNG ĐOÀN</span></h4>
                            </li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-16 ">
                            <?php $__currentLoopData = $congdoannew; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cdn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a title="<?php echo e($cdn->tieude); ?>" href="vanban/congdoan/<?php echo e($cdn->tieude); ?>/<?php echo e($cdn->filename); ?>"><img src="congdoan/img/<?php echo e($cdn->imgname); ?>" alt="" style="width: 210px; height: 300px;"  class="img-thumbnail pull-left imghome" />
                                </a>
                                <h3>
                                    <a title="<?php echo e($cdn->tieude); ?>" href="vanban/congdoan/<?php echo e($cdn->tieude); ?>/<?php echo e($cdn->filename); ?>" ><?php echo e($cdn->tieude); ?></a>
                                </h3>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                              
                            </div>
                            <div class="col-md-8  border-left-content">
                                <ul class="related">
                                    <?php $__currentLoopData = $congdoan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="icon_list">
                                        <a class="show h4" href="vanban/congdoan/<?php echo e($cd->tieude); ?>/<?php echo e($cd->filename); ?>" title="<?php echo e($cd->tieude); ?>" data-content="" data-img="congdoan/vanban/<?php echo e($cd->filename); ?>" data-rel="tooltip" data-placement="top"><?php echo e($cd->tieude); ?></a>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="news_column">
                <div class="panel panel-default clearfix">
                    <div class="panel-heading">
                        <ul class="list-inline sub-list-icon" style="margin: 0">
                            <li style="width:200px; text-align: center">
                                <h4><span>Tin Đoàn Thể</span></h4>
                            </li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-16 ">
                            <?php $__currentLoopData = $tindoanthenew; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tdtn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a title="<?php echo e($tdtn->tieude); ?>" href="vanban/tindoanthe/<?php echo e($tdtn->tieude); ?>/<?php echo e($tdtn->filename); ?>"><img src="tindoanthe/img/<?php echo e($tdtn->imgname); ?>" alt="" style="width: 210px; height: 300px;"  class="img-thumbnail pull-left imghome" />
                                </a>
                                <h3>
                                    <a title="<?php echo e($tdtn->tieude); ?>" href="vanban/tindoanthe/<?php echo e($tdtn->tieude); ?>/<?php echo e($tdtn->filename); ?>" ><?php echo e($tdtn->tieude); ?></a>
                                </h3>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                              
                            </div>
                            <div class="col-md-8  border-left-content">
                                <ul class="related">
                                    <?php $__currentLoopData = $tindoanthe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tdt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="icon_list">
                                        <a class="show h4" href="vanban/tindoanthe/<?php echo e($tdt->tieude); ?>/<?php echo e($tdt->filename); ?>" title="<?php echo e($tdt->tieude); ?>" data-content="" data-img="tindoanthe/vanban/<?php echo e($tdt->filename); ?>" data-rel="tooltip" data-placement="top"><?php echo e($tdt->tieude); ?></a>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="news_column">
                <div class="panel panel-default clearfix">
                    <div class="panel-heading">
                        <ul class="list-inline sub-list-icon" style="margin: 0">
                            <li style="width:250px; text-align: center">
                                <h4><span>HOẠT ĐỘNG NGOÀI GIỜ LÊN LỚP</span></h4>
                            </li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-16 ">
                            <?php $__currentLoopData = $hdngllnew; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datahdn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                                <a title="<?php echo e($datahdn->tieude); ?>" href="vanban/hdngoaigiolenlop/<?php echo e($datahdn->tieude); ?>/<?php echo e($datahdn->filename); ?>"><img src="hdngoaigiolenlop/img/<?php echo e($datahdn->imgname); ?>" alt="" style="width: 210px; height: 300px;"  class="img-thumbnail pull-left imghome" />
                                </a>
                                <h3>
                                    <a title="<?php echo e($datahdn->tieude); ?>" href="vanban/hdngoaigiolenlop/<?php echo e($datahdn->tieude); ?>/<?php echo e($datahdn->filename); ?>" ><?php echo e($datahdn->tieude); ?></a>
                                </h3>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                              
                            </div>
                            <div class="col-md-8  border-left-content">
                                <ul class="related">
                                    <?php $__currentLoopData = $hdngll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datahd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="icon_list">
                                        <a class="show h4" href="vanban/hdngoaigiolenlop/<?php echo e($datahdn->tieude); ?>/<?php echo e($datahdn->filename); ?>" title="<?php echo e($datahd->tieude); ?>" data-content="" data-img="hdngoaigiolenlop/vanban/<?php echo e($datahd->filename); ?>" data-rel="tooltip" data-placement="top"><?php echo e($datahd->tieude); ?></a>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-7 col-md-6">
            <div class="panel panel-green">
                <div class="panel-heading">
                    VIDEO
                </div>
                
                <div class="panel-body">
                    <?php $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <video width="237" height="239"  src="video/<?php echo e($vd->link); ?>" controls></video>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div style="margin-top: 40px " class="panel panel-green">
                <div class="panel-heading">
                    BẢN ĐỒ VỊ TRÍ
                </div>
                <div class="panel-body">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1750.7989182745844!2d104.86588208390731!3d21.593196794050957!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xd89bf35f7104f6f0!2zVHLGsOG7nW5nIHRydW5nIGjhu41jIGPGoSBz4bufIFbDom4gSOG7mWk!5e0!3m2!1svi!2s!4v1620701498699!5m2!1svi!2s" 
                    width="237" height="347" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
            </div>

            <div style="margin-top: 53px " class="panel panel-green">
                <div class="panel-heading">
                    QUẢN LÝ
                </div>
                <div class="panel-body">
                    <p>HT: Trần Thị Hồng Tuyến</p>
                   
                </div>
            </div>

            <div class="panel panel-white">
                <div class="panel-heading">
                    Thư viện ảnh
                </div>
                <div class="panel-body">
                    <ul class="list_album">
                        <?php $__currentLoopData = $chudeanh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           
                            <li class="text-center">
                                <a href="anh/<?php echo e($cna->id); ?>" title="<?php echo e($cna->tenchude); ?>">
                                    <img style="width: 105px; height: 130px;"  src="anhnhatruong/<?php echo e($cna->anhdaidien); ?>" class="img-thumbnail" alt="<?php echo e($cna->tenchude); ?>"  />
                                </a>
                                <b></b>
                                <a style="color: blue" href="anh/<?php echo e($cna->id); ?>" title="<?php echo e($cna->tenchude); ?>"><?php echo e($cna->tenchude); ?></a>
                            </li>
                          
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </ul>
                </div>
            </div>
        
        </div>
    </div>

    

<?php $__env->stopSection(); ?>
    
  
<?php echo $__env->make('layout.LTindex', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thptvanhoi\resources\views/index.blade.php ENDPATH**/ ?>