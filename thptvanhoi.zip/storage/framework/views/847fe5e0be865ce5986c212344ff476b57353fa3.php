
<?php $__env->startSection('NoiDung'); ?>

<div class="container-fluid">
    <div style="padding-top: 3%;padding-bottom: 1%; text-align: center">
        <h2 >Quản lý tài khoản</h2>
    </div>

    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
        <tr align="center">
            <th>SĐT</th>
            <th>Tên đăng nhập</th>
            <th>Tên giáo viên</th>
            <th>Email</th>
            <th>Xem thông tin</th>
            <th>Xóa</th>
        </tr>
         <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr class="odd gradeX" align="center">
             <td>0<?php echo e($us->id); ?></td>
             <td><?php echo e($us->name); ?></td>
             <td><?php echo e($us->getGV->hoten); ?></td>
             <td><?php echo e($us->email); ?></td>
             <td><a href="admin/thongtingv/<?php echo e($us->id); ?>">Xem thông tin</a></td>
             <td><a href="admin/xoa/<?php echo e($us->id); ?>">Xóa</a></td>
         </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>










<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thptvanhoi\resources\views/admin/QuanlyTKGV.blade.php ENDPATH**/ ?>