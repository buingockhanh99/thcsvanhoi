
<?php $__env->startSection('NoiDung'); ?>

<div class="container-fluid">
    <div style="padding-top: 3%;padding-bottom: 1%; text-align: center">
        <?php switch($noidung):
            case (1): ?>
            <h2>Nội dung sửa tin Công Đoàn</h2>
            <?php break; ?>
            <?php case (2): ?>
            <h2>Nội dung sửa Hoạt động ngoài giờ lên lớp</h2>
            <?php break; ?>
            <?php case (3): ?>
            <h2>Nội dung sửa tin Đoàn thể</h2>
            <?php break; ?>
            <?php case (4): ?>
            <h2>Nội dung sửa tin Mới nhất</h2>
            <?php break; ?>
            <?php case (5): ?>
            <h2>Nội dung sửa Tin Nhanh</h2>
            <?php break; ?>
            <?php case (6): ?>
            <h2>Nội dung sửa tin Nhà trường</h2>
            <?php break; ?>
            <?php case (7): ?>
            <h2>Nội dung sửa văn bản Cấp Sở</h2>
            <?php break; ?>
            <?php case (8): ?>
            <h2>Nội dung sửa văn bản Mới</h2>
            <?php break; ?>
            <?php case (9): ?>
            <h2>Nội dung sửa văn bản Trường</h2>
            <?php break; ?>
            <?php case (10): ?>
            <h2>Update Video</h2>
            <?php break; ?>
            <?php default: ?>
            <h2>Không có nội dung</h2>
        <?php endswitch; ?>
        
    </div>

    
     <?php if(count($errors)>0): ?>
            <div class="alert alert-danger" style="width: 40%; text-align: center; margin-left: 30%">
                <?php $__currentLoopData = $errors ->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($err); ?><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <?php if(session('thongbaoloi')): ?>
            <div class="alert alert-danger" style="width: 40%; text-align: center;">
                <?php echo e(session('thongbaoloi')); ?>

            </div>
        <?php endif; ?>
    <?php if(isset($data)): ?>
        <?php switch($noidung):
            case (1): ?>
                <form  action="admin/noidungsua/<?php echo e($data->id); ?>/key/congdoan" method="POST" enctype="multipart/form-data" >
                    <?php echo e(csrf_field()); ?>

                    <div  style="padding-left: 36%;">
                        <table>
                            <tr>
                                <th>Tiêu đề</th>
                                <td  style="padding-left: 5%;"><input type="text" value="<?php echo e($data->tieude); ?>" name="tieude" style="width: 270px;" ></td>
                            </tr>
                            <tr style="height: 20px">
            
                            </tr>
                            <tr>
                                <th>File</th>
                                <td style="padding-left: 5%;"><input type="file"  name="file" accept=".doc,.docx" ></td>
                            </tr>
            
                            <tr style="height: 20px"></tr>
                            <tr>
                                <th>Ảnh</th>
                                <td style="padding-left: 5%;"><input type="file"  name="img" accept="image/png, image/jpeg" ></td>
                            </tr>
                            <tr style="height: 50px"></tr>
                            <tr style="color: red">
                                <th>Lưu ý</th>
                                <td>Nếu không thay đổi Ảnh hoặc File thì để nguyên</td>
                            </tr>
                            <tr style="height: 20px"></tr>
                        </table> 
                        
                        <div style="padding-left: 13%">
                            <input type="submit" class="btn btn-primary" value="Sửa" style="width: 170px;" />
                        </div>
                        <div style="height: 30px;"></div>
                        
                    </div>
                </form>
            <?php break; ?>

            <?php case (2): ?>
                <form  action="admin/noidungsua/<?php echo e($data->id); ?>/key/hdngoaigio" method="POST" enctype="multipart/form-data" >
                    <?php echo e(csrf_field()); ?>

                    <div  style="padding-left: 36%;">
                        <table>
                            <tr>
                                <th>Tiêu đề</th>
                                <td  style="padding-left: 5%;"><input type="text" value="<?php echo e($data->tieude); ?>" placeholder="Tiêu đề" name="tieude" style="width: 270px;" ></td>
                            </tr>
                            <tr style="height: 20px">
            
                            </tr>
                            <tr>
                                <th>File</th>
                                <td style="padding-left: 5%;"><input type="file"  name="file" accept=".doc,.docx" ></td>
                            </tr>
            
                            <tr style="height: 20px"></tr>
                            <tr>
                                <th>Ảnh</th>
                                <td style="padding-left: 5%;"><input type="file"  name="img" accept="image/png, image/jpeg" ></td>
                            </tr>
                            <tr style="height: 50px"></tr>
                            <tr style="color: red">
                                <th>Lưu ý</th>
                                <td>Nếu không thay đổi Ảnh hoặc File thì để nguyên</td>
                            </tr>
                            <tr style="height: 20px"></tr>
                        </table> 
                        
                        <div style="padding-left: 13%">
                            <input type="submit" class="btn btn-primary" value="Sửa" style="width: 170px;" />
                        </div>
                        <div style="height: 30px;"></div>
                    </div>
                </form>
            <?php break; ?>

            <?php case (3): ?>
                <form  action="admin/noidungsua/<?php echo e($data->id); ?>/key/tindoanthe" method="POST" enctype="multipart/form-data" >
                    <?php echo e(csrf_field()); ?>

                    <div  style="padding-left: 36%;">
                        <table>
                            <tr>
                                <th>Tiêu đề</th>
                                <td  style="padding-left: 5%;"><input type="text" value="<?php echo e($data->tieude); ?>" placeholder="Tiêu đề" name="tieude" style="width: 270px;" ></td>
                            </tr>
                            <tr style="height: 20px">
            
                            </tr>
                            <tr>
                                <th>File</th>
                                <td style="padding-left: 5%;"><input type="file"  name="file" accept=".doc,.docx" ></td>
                            </tr>
            
                            <tr style="height: 20px"></tr>
                            <tr>
                                <th>Ảnh</th>
                                <td style="padding-left: 5%;"><input type="file"  name="img" accept="image/png, image/jpeg" ></td>
                            </tr>
                            <tr style="height: 50px"></tr>
                            <tr style="color: red">
                                <th>Lưu ý</th>
                                <td>Nếu không thay đổi Ảnh hoặc File thì để nguyên</td>
                            </tr>
                            <tr style="height: 20px"></tr>
                        </table> 
                        
                        <div style="padding-left: 13%">
                            <input type="submit" class="btn btn-primary" value="Sửa" style="width: 170px;" />
                        </div>
                        <div style="height: 30px;"></div>
                    </div>
                </form>
            <?php break; ?>

            <?php case (4): ?>
                <form  action="admin/noidungsua/<?php echo e($data->id); ?>/key/tinmoinhat"  method="POST" enctype="multipart/form-data" >
                    <?php echo e(csrf_field()); ?>

                    <div  style="padding-left: 36%;">
                        <table>
                            <tr>
                            <th>Tiêu đề</th>
                                <td  style="padding-left: 5%;"><input type="text" value="<?php echo e($data->tieude); ?>" placeholder="Tiêu đề" name="tieude" style="width: 270px;" ></td>
                            </tr>
                            <tr style="height: 20px">
                            </tr>
                            <tr>
                                <th>File</th>
                                <td style="padding-left: 5%;"><input type="file"  name="file" accept=".doc,.docx"></td>
                            </tr>
                            <tr style="height: 20px">
                            </tr>
                            <tr>
                                <th>Ảnh</th>
                                <td style="padding-left: 5%;"><input type="file"  name="img" accept="image/png, image/jpeg"></td>
                            </tr>
            
                            <tr style="height: 50px"></tr>
                            <tr style="color: red">
                                <th>Lưu ý</th>
                                <td>Nếu không thay đổi Ảnh hoặc File thì để nguyên</td>
                            </tr>
                            <tr style="height: 20px"></tr>
                        </table> 

                        <div style="padding-left: 13%">
                            <input type="submit" class="btn btn-primary" value="Sửa" style="width: 170px;" />
                        </div>
            
                        <div style="height: 15px;"></div>
                </form>
            <?php break; ?>

            <?php case (5): ?>
                <form  action="admin/noidungsua/<?php echo e($data->id); ?>/key/tinnhanh" method="POST" enctype="multipart/form-data" >
                    <?php echo e(csrf_field()); ?>

                    <div  style="padding-left: 36%;">
                        <table>
                            <tr>
                            <th>Tiêu đề</th>
                                <td  style="padding-left: 5%;"><input value="<?php echo e($data->tieude); ?>" type="text" placeholder="Tiêu đề" name="tieude" style="width: 270px;" ></td>
                            </tr>
            
                            <tr style="height: 20px">
                            </tr>
                            <tr>
                                <th>File</th>
                                <td style="padding-left: 5%;"><input type="file"  name="file" accept=".doc,.docx"></td>
                            </tr>
            
                            <tr style="height: 50px"></tr>
                            <tr style="color: red">
                                <th>Lưu ý</th>
                                <td>Nếu không thay đổi Ảnh hoặc File thì để nguyên</td>
                            </tr>
                            <tr style="height: 20px"></tr>
                        </table> 
                        
                        <div style="padding-left: 13%">
                            <input type="submit" class="btn btn-primary" value="Sửa" style="width: 170px;" />
                        </div>
                        <div style="height: 15px;"></div>
                </form>
            <?php break; ?>

            <?php case (6): ?>
                <form  action="admin/noidungsua/<?php echo e($data->id); ?>/key/tinnhatruong" method="POST" enctype="multipart/form-data" >
                    <?php echo e(csrf_field()); ?>

                    <div  style="padding-left: 36%;">
                        <table>
                            <tr>
                                <th>Tiêu đề</th>
                                <td  style="padding-left: 5%;"><input value="<?php echo e($data->tieude); ?>" type="text" placeholder="Tiêu đề" name="tieude" style="width: 270px;" ></td>
                            </tr>
                            <tr style="height: 20px">
            
                            </tr>
                            <tr>
                                <th>File</th>
                                <td style="padding-left: 5%;"><input type="file"  name="file" accept=".doc,.docx"></td>
                            </tr>
            
                            <tr style="height: 20px"></tr>
            
                            <tr>
                                <th>Ảnh</th>
                                <td style="padding-left: 5%;"><input type="file"  name="img" accept="image/png, image/jpeg" ></td>
                            </tr>
            
                            <tr style="height: 50px"></tr>
                            <tr style="color: red">
                                <th>Lưu ý</th>
                                <td>Nếu không thay đổi Ảnh hoặc File thì để nguyên</td>
                            </tr>
                            <tr style="height: 20px"></tr>
                        </table> 
                        
                        <div style="padding-left: 13%">
                            <input type="submit" class="btn btn-primary" value="Sửa" style="width: 170px;" />
                        </div>
                        <div style="height: 30px;"></div>
                    </div>
                </form>
            <?php break; ?>

            <?php case (7): ?>
                <form  action="admin/noidungsua/<?php echo e($data->id); ?>/key/vbcs" method="POST" enctype="multipart/form-data" >
                    <?php echo e(csrf_field()); ?>

                    <div  style="padding-left: 36%;">
                        <table>
                            <tr>
                                <th>Tiêu đề</th>
                                <td  style="padding-left: 5%;"><input value="<?php echo e($data->tieude); ?>" type="text" placeholder="Tiêu đề" name="tieude" style="width: 270px;" ></td>
                            </tr>
                            <tr style="height: 20px">
            
                            </tr>
                            <tr>
                                <th>File</th>
                                <td style="padding-left: 5%;"><input type="file"  name="file" accept=".doc,.docx" ></td>
                            </tr>
            
                            <tr style="height: 50px"></tr>
                            <tr style="color: red">
                                <th>Lưu ý</th>
                                <td>Nếu không thay đổi Ảnh hoặc File thì để nguyên</td>
                            </tr>
                            <tr style="height: 20px"></tr>
                        </table> 
                        
                        <div style="padding-left: 13%">
                            <input type="submit" class="btn btn-primary" value="Sửa" style="width: 170px;" />
                        </div>
            
                        <div style="height: 30px;"></div>
                    </div>
                </form>
            <?php break; ?>

            <?php case (8): ?>
                <form  action="admin/noidungsua/<?php echo e($data->id); ?>/key/vbmoi" method="POST" enctype="multipart/form-data" >
                    <?php echo e(csrf_field()); ?>

                    <div  style="padding-left: 36%;">
                        <table>
                            <tr>
                            <th>Tiêu đề</th>
                                <td  style="padding-left: 5%;"><input value="<?php echo e($data->tieude); ?>" type="text"  placeholder="Tiêu đề" name="tieude" style="width: 270px;" ></td>
                            </tr>
                            <tr style="height: 20px">
            
                            </tr>
                            <tr>
                                <th>File</th>
                                <td style="padding-left: 5%;"><input type="file" name="file" accept=".doc,.docx" ></td>
                            </tr>
            
                            <tr style="height: 50px"></tr>
                            <tr style="color: red">
                                <th>Lưu ý</th>
                                <td>Nếu không thay đổi Ảnh hoặc File thì để nguyên</td>
                            </tr>
                            <tr style="height: 20px"></tr>
                        </table> 
                        
                        <div style="padding-left: 13%">
                            <input type="submit" class="btn btn-primary" value="Sửa" style="width: 170px;" />
                        </div>
                        <div style="height: 30px;"></div>
                    </div>
                </form>
            <?php break; ?>

            <?php case (9): ?>
                <form  action="admin/noidungsua/<?php echo e($data->id); ?>/key/vbt" method="POST" enctype="multipart/form-data" >
                    <?php echo e(csrf_field()); ?>

                    <div  style="padding-left: 36%;">
                        <table>
                            <tr>
                                <th>Tiêu đề</th>
                                <td  style="padding-left: 5%;"><input value="<?php echo e($data->tieude); ?>" type="text" placeholder="Tiêu đề" name="tieude" style="width: 270px;" ></td>
                            </tr>
                            <tr style="height: 20px">
            
                            </tr>
                            <tr>
                                <th>File</th>
                                <td style="padding-left: 5%;"><input type="file"  name="file" accept=".doc,.docx" ></td>
                            </tr>
            
                            <tr style="height: 50px"></tr>
                            <tr style="color: red">
                                <th>Lưu ý</th>
                                <td>Nếu không thay đổi Ảnh hoặc File thì để nguyên</td>
                            </tr>
                            <tr style="height: 20px"></tr>
                        </table> 
                        
                        <div style="padding-left: 13%">
                            <input type="submit" class="btn btn-primary" value="Sửa" style="width: 170px;" />
                        </div>
                        <div style="height: 30px;"></div>
                    </div>
                </form>
            <?php break; ?>


            <?php case (10): ?>
                <form  action="admin/noidungsua/<?php echo e($data->id); ?>/key/video" method="POST" enctype="multipart/form-data" >
                    <?php echo e(csrf_field()); ?>

                    <div  style="padding-left: 36%; padding-bottom: 25px">
                        <table>
                            <tr>
                                <th>VIDEO</th>
                                <td style="padding-left: 5%;"><input type="file"  name="file" accept=".mp4" ></td>
                            </tr>

                            
                        </table> 
                        <div style="height: 30px;"></div>
                        <div style="padding-left: 8%">
                            <input type="submit" class="btn btn-primary" value="THAY ĐỔI" style="width: 270px;" />
                        </div>
                        
                    </div>
                </form>
            <?php break; ?>

            <?php default: ?>
            <h1>Không có nội dung gửi tới</h1>
        <?php endswitch; ?>
      
       
    <?php endif; ?>
   
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thptvanhoi\resources\views/admin/noidungsua.blade.php ENDPATH**/ ?>