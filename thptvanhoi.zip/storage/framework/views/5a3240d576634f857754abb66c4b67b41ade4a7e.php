
<?php $__env->startSection('NoiDung'); ?>

<div class="container-fluid">
    <div style="padding-top: 3%;padding-bottom: 1%; text-align: center">
        <h2 >Quản lý Video</h2>
    </div>
    <div style="height: 30px;"></div>
    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
        <tr align="center">
           
            <th>VIDEO</th>
            <th>THAY ĐỔI</th>
           
        </tr>
      
         <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr class="odd gradeX" align="center" style="line-height: 100px">
             
             <td>  
                <video width="500px" height="200"  src="video/<?php echo e($dt->link); ?>" controls></video>
               
                </td>
             <td><button class="btn btn-primary"><a style="color: seashell" href="admin/noidungsua/<?php echo e($dt->id); ?>/key/<?php echo e($key='video'); ?>"><i class="fas fa-edit"></i></a></button></td>
         </tr>
      
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <div style="height: 30px;"></div>
  
    <?php if(session('thongbao')): ?>
    <div class="alert alert-success" style="width: 500px; margin-left: 29%; text-align: center">
        <?php echo e(session('thongbao')); ?>

    </div>
    <?php endif; ?>

    


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thptvanhoi\resources\views/admin/quanly/video.blade.php ENDPATH**/ ?>