
<?php $__env->startSection('NoiDung'); ?>

      <marquee style="height: 50px; width: 100%;line-height: 50px; font-size: 40px; color: red; margin-top: 30px" direction="left">
        CHÀO MỪNG TỚI TRANG QUẢN TRỊ TRƯỜNG TH & THCS VÂN HỘI
      </marquee>
      
      <h1 style="font-size: 60px; text-align: center;margin-top:10% ">ADMIN</h1>
<?php $__env->stopSection(); ?>

 
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thptvanhoi\resources\views/admin/index.blade.php ENDPATH**/ ?>