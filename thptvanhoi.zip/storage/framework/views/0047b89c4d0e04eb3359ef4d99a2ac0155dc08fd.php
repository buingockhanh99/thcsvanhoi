
<?php $__env->startSection('NoiDung'); ?>

<div class="container-fluid">
    <div style="padding-top: 3%;padding-bottom: 1%; text-align: center">
        <?php if($noidung==1): ?>
        <h2>Nội dung xóa tin Công Đoàn</h2>
        <?php elseif($noidung==2): ?>
        <h2>Nội dung xóa Hoạt động ngoài giờ lên lớp</h2>
        <?php elseif($noidung==3): ?>
        <h2>Nội dung xóa tin Đoàn thể</h2>
        <?php elseif($noidung==4): ?>
        <h2>Nội dung xóa tin Mới nhất</h2>
        <?php elseif($noidung==5): ?>
        <h2>Nội dung xóa Tin Tuyển Sinh</h2>
        <?php elseif($noidung==6): ?>
        <h2>Nội dung xóa tin Nhà trường</h2>
        <?php elseif($noidung==7): ?>
        <h2>Nội dung xóa văn bản Cấp Sở</h2>
        <?php elseif($noidung==8): ?>
        <h2>Nội dung xóa văn bản Mới</h2>
        <?php elseif($noidung==9): ?>
        <h2>Nội dung xóa văn bản Trường</h2>
        <?php else: ?>
        <h1>Null</h1>
        <?php endif; ?>
    </div>


    <?php if(isset($data)): ?>
        <?php if($noidung==1): ?>

            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                <tr align="center">
                    <th>id</th>
                    <th>tieude</th>
                    <th>data</th>
                    <th>Ảnh</th>
                </tr>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="odd gradeX" align="center" style="line-height: 100px">
                    <td><?php echo e($dt->id); ?></td>
                    <td><?php echo e($dt->tieude); ?></td>
                    <td><a href="congdoan/vanban/<?php echo e($dt->filename); ?>"><?php echo e($dt->filename); ?></a></td>
                    <td><img src="congdoan/img/<?php echo e($dt->imgname); ?>" alt="" width="100px"></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <button class="btn btn-primary" onclick="quay_lai()">Trở lại</button>
            <button class="btn btn-danger" style="margin-left: 43%"><a href="admin/xoa/<?php echo e($dt->id); ?>/key/<?php echo e($key='congdoan'); ?>" style="color: seashell">Xác nhận xóa</a></button>
        <?php elseif($noidung==2): ?>
            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                <tr align="center">
                    <th>ID</th>
                    <th>Tiêu đề</th>
                    <th>Data</th>
                    <th>Ảnh</th>
                    
                </tr>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="odd gradeX" align="center" style="line-height: 100px">
                    <td><?php echo e($dt->id); ?></td>
                    <td><?php echo e($dt->tieude); ?></td>
                    <td><a href="hdngoaigiolenlop/vanban/<?php echo e($dt->filename); ?>"><?php echo e($dt->filename); ?></a></td>
                    <td><img src="hdngoaigiolenlop/img/<?php echo e($dt->imgname); ?>" alt="" width="100px"></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <button class="btn btn-primary" onclick="quay_lai()">Trở lại</button>
            <button class="btn btn-danger" style="margin-left: 43%"><a href="admin/xoa/<?php echo e($dt->id); ?>/key/<?php echo e($key='hdngoaigio'); ?>" style="color: seashell">Xác nhận xóa</a></button>
        <?php elseif($noidung==3): ?>
            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                <tr align="center">
                    <th>ID</th>
                    <th>Tiêu đề</th>
                    <th>Data</th>
                    <th>Ảnh</th>
                    
                </tr>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="odd gradeX" align="center" style="line-height: 100px">
                    <td><?php echo e($dt->id); ?></td>
                    <td><?php echo e($dt->tieude); ?></td>
                    <td><a href="tindoanthe/vanban/<?php echo e($dt->filename); ?>"><?php echo e($dt->filename); ?></a></td>
                    <td><img src="tindoanthe/img/<?php echo e($dt->imgname); ?>" alt="admin/xoa/<?php echo e($dt->id); ?>/key/<?php echo e($key='tindoanthe'); ?>" width="100px"></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <button class="btn btn-primary" onclick="quay_lai()">Trở lại</button>
            <button class="btn btn-danger" style="margin-left: 43%"><a href="admin/xoa/<?php echo e($dt->id); ?>/key/<?php echo e($key='tindoanthe'); ?>" style="color: seashell">Xác nhận xóa</a></button>
        <?php elseif($noidung==4): ?>
            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                <tr align="center">
                    <th>ID</th>
                    <th>Tiêu đề</th>
                    <th>Data</th>
                    <th>Ảnh</th>
                </tr>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="odd gradeX" align="center" style="line-height: 100px">
                    <td><?php echo e($dt->id); ?></td>
                    <td><?php echo e($dt->tieude); ?></td>
                    <td><a href="tinmoinhat/vanban/<?php echo e($dt->filename); ?>"><?php echo e($dt->filename); ?></a></td>
                    <td><img src="tinmoinhat/img/<?php echo e($dt->imgname); ?>" alt="" width="100px"></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <button class="btn btn-primary" onclick="quay_lai()">Trở lại</button>
            <button class="btn btn-danger" style="margin-left: 43%"><a href="admin/xoa/<?php echo e($dt->id); ?>/key/<?php echo e($key='tinmoinhat'); ?>" style="color: seashell">Xác nhận xóa</a></button>
        <?php elseif($noidung==5): ?>
            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                <tr align="center">
                    <th>ID</th>
                    <th>Tiêu đề</th>
                    <th>Data</th>
                </tr>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="odd gradeX" align="center" >
                    <td><?php echo e($dt->id); ?></td>
                    <td><?php echo e($dt->tieude); ?></td>
                    <td><a href="tinnhanh/<?php echo e($dt->filename); ?>"><?php echo e($dt->filename); ?></a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <button class="btn btn-primary" onclick="quay_lai()">Trở lại</button>
            <button class="btn btn-danger" style="margin-left: 43%"><a href="admin/xoa/<?php echo e($dt->id); ?>/key/<?php echo e($key='tinnhanh'); ?>" style="color: seashell">Xác nhận xóa</a></button>
        <?php elseif($noidung==6): ?>
            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                <tr align="center">
                    <th>ID</th>
                    <th>Tiêu đề</th>
                    <th>Data</th>
                    <th>Ảnh</th>
                </tr>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="odd gradeX" align="center" style="line-height: 100px">
                    <td><?php echo e($dt->id); ?></td>
                    <td><?php echo e($dt->tieude); ?></td>
                    <td><a href="tinnhatruong/vanban/<?php echo e($dt->filename); ?>"><?php echo e($dt->filename); ?></a></td>
                    <td><img src="tinnhatruong/img/<?php echo e($dt->imgname); ?>" alt="" width="100px"></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <button class="btn btn-primary" onclick="quay_lai()">Trở lại</button>
            <button class="btn btn-danger" style="margin-left: 43%"><a href="admin/xoa/<?php echo e($dt->id); ?>/key/<?php echo e($key='tinnhatruong'); ?>" style="color: seashell">Xác nhận xóa</a></button>
        <?php elseif($noidung==7): ?>
            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                <tr align="center">
                    <th>ID</th>
                    <th>Tiêu đề</th>
                    <th>Thời gian đăng</th>
                    <th>Data</th>
                </tr>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="odd gradeX" align="center">
                    <td><?php echo e($dt->id); ?></td>
                    <td><?php echo e($dt->tieude); ?></td>
                    <td><?php echo e($dt->ngay); ?>-<?php echo e($dt->thang); ?>-<?php echo e($dt->nam); ?></td>
                    <td><a href="vanbantruong/<?php echo e($dt->filename); ?>"><?php echo e($dt->filename); ?></a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <button class="btn btn-primary" onclick="quay_lai()">Trở lại</button>
            <button class="btn btn-danger" style="margin-left: 43%"><a href="admin/xoa/<?php echo e($dt->id); ?>/key/<?php echo e($key='vbcs'); ?>" style="color: seashell">Xác nhận xóa</a></button>
        <?php elseif($noidung==8): ?>
            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                <tr align="center">
                    <th>ID</th>
                    <th>Tiêu đề</th>
                    <th>Data</th>
                </tr>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="odd gradeX" align="center">
                    <td><?php echo e($dt->id); ?></td>
                    <td><?php echo e($dt->tieude); ?></td>
                    <td><a href="vanbanmoi/<?php echo e($dt->filename); ?>"><?php echo e($dt->filename); ?></a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <button class="btn btn-primary" onclick="quay_lai()">Trở lại</button>
            <button class="btn btn-danger" style="margin-left: 43%"><a href="admin/xoa/<?php echo e($dt->id); ?>/key/<?php echo e($key='vbmoi'); ?>" style="color: seashell">Xác nhận xóa</a></button>
        <?php elseif($noidung==9): ?>
            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                <tr align="center">
                    <th>ID</th>
                    <th>Tiêu đề</th>
                    <th>Thời gian đăng</th>
                    <th>Data</th>
                </tr>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="odd gradeX" align="center">
                    <td><?php echo e($dt->id); ?></td>
                    <td><?php echo e($dt->tieude); ?></td>
                    <td><?php echo e($dt->ngay); ?>-<?php echo e($dt->thang); ?>-<?php echo e($dt->nam); ?></td>
                    <td><a href="vanbantruong/<?php echo e($dt->filename); ?>"><?php echo e($dt->filename); ?></a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <button class="btn btn-primary" onclick="quay_lai()">Trở lại</button>
            <button class="btn btn-danger" style="margin-left: 43%"><a href="admin/xoa/<?php echo e($dt->id); ?>/key/<?php echo e($key='vbt'); ?>" style="color: seashell">Xác nhận xóa</a></button>
        <?php else: ?>
        <h1 style="text-align: center">Chưa có nội dung được gửi tới</h1>
        <?php endif; ?>
        

    <?php else: ?>
    <h1 style="text-align: center">Chưa có nội dung được gửi tới</h1>
    <?php endif; ?>
        
   
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thptvanhoi\resources\views/admin/noidungxoa.blade.php ENDPATH**/ ?>