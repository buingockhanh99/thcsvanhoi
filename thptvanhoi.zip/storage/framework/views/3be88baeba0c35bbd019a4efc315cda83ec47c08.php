
<?php $__env->startSection('NoiDung'); ?>

<div class="container-fluid">
    <div style="padding-top: 3%;padding-bottom: 1%; text-align: center">
        <h2>Thông tin giáo viên</h2>
    </div>

    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
        <tr align="center">
            <th>Ảnh</th>
            <th>Họ Tên</th>
            <th>Địa chỉ</th>
            <th>Số điện thoại</th>
            <th>Giới tính</th>
            <th>Ngày sinh</th>
            <th>Reset mật khẩu</th>
            
        </tr>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr class="odd gradeX" align="center">
             <td><img src="<?php echo e(asset('imggv/'.$dt->anh)); ?>" alt="" height="100px" width="100px"></td>
             <td style="padding-top: 5%; "><?php echo e($dt->hoten); ?></td>
             <td style="padding-top: 5%; "><?php echo e($dt->diachi); ?></td>
             <td style="padding-top: 5%; "><?php echo e($dt->sdt); ?></td>
             <td style="padding-top: 5%;"><?php echo e($dt->gioitinh); ?></td>
             <td style="padding-top: 5%;"><?php echo e($dt->ngaysinh); ?></td>
             <td style="padding-top: 5%"><a href="admin/resetpass/<?php echo e($dt->id_gv); ?>"><i class="fas fa-lock-open"></i></a></td>
         </tr>
        
    </table>
    <div style="height: 20px"></div>
    <button class="btn btn-primary"><a href="<?php echo e(route('QuanLyTKGV')); ?>" style="color: seashell">Trở lại</a></button>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <button class="btn btn-danger" style="float: right"><a href="admin/xoa/<?php echo e($dt->id_gv); ?>/key/giaovien" style="color: seashell"><i class="fas fa-trash-alt"></i></a></button>
</div>

    <div style="height: 30px"></div>

    <?php if(session('thongbao')): ?>
    <div class="alert alert-primary" style="margin-left: 35%;width: 40%; text-align: center;">
        <?php echo e(session('thongbao')); ?>

    </div>
    <?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thptvanhoi\resources\views/admin/thongtingv.blade.php ENDPATH**/ ?>