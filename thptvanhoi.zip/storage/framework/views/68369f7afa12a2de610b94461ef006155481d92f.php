
<?php $__env->startSection('NoiDung'); ?>

<div class="container-fluid">
    <div style="text-align: center;padding-top: 3%;padding-bottom: 1%;">
        <h2>Thêm chủ đề ảnh</h2>
    </div>
    
    <form  action="<?php echo e(route('Paddcda')); ?>" method="POST" >
        <?php echo e(csrf_field()); ?>

        <div  style="padding-left: 36%;">
            <table>
                <tr>
                    <th>Chủ đề ảnh</th>
                    <td  style="padding-left: 5%;"><input type="text"  placeholder="Chủ đề ảnh" name="chudeanh" style="width: 270px;" ></td>
                </tr>
                <tr style="height: 20px">

                </tr>
                
            </table> 
            
            <div style="padding-left: 11%">
                <input type="submit" class="btn btn-primary" value="Tải lên" style="width: 170px;" />
                <input type="reset" class="btn btn-primary"  value="Reset form">
            </div>
            <div style="height: 30px;"></div>
            <?php if(count($errors)>0): ?>
                <div class="alert alert-danger" style="width: 45%">
                    <?php $__currentLoopData = $errors ->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($err); ?><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <?php if(session('thongbaoloi')): ?>
                <div class="alert alert-danger" style="width: 45%">
                    <?php echo e(session('thongbaoloi')); ?>

                </div>
            <?php endif; ?>

        
            
            
        </div>
        
    </form>
    
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thptvanhoi\resources\views/admin/add/chudeanh.blade.php ENDPATH**/ ?>