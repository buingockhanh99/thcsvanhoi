<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<?php 
$id=1;
 $data = DB::table('anh')->where('idchude',$id)->orderBy('id', 'desc')->take(1)->get();

// $data = chudeanh::find(1)->getIMG->take(1);
?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<img width="500px" height="500px" src="anhnhatruong/<?php echo e($dt->filename); ?>" alt="">


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
 
   
</body>
</html><?php /**PATH C:\xampp\htdocs\thptvanhoi\resources\views/test.blade.php ENDPATH**/ ?>