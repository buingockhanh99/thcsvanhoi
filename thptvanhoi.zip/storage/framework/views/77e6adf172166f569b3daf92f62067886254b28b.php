
<?php $__env->startSection('NoiDung'); ?>

<div class="container-fluid">
    <div style="padding-top: 3%;padding-bottom: 1%; text-align: center">
        <h2 >Quản lý Tin Tuyển Sinh</h2>
    </div>
    <div><button class="btn btn-primary" style="width: 150px;"><i class="fas fa-plus"></i><a style="color: #fff" href="<?php echo e(route('addTN')); ?>"> Thêm tin mới</a></button></div>
    <div style="height: 30px;"></div>
    <?php if(session('thongbao')): ?>
    <div class="alert alert-success" style="width: 500px; margin-left: 29%; text-align: center">
        <?php echo e(session('thongbao')); ?>

    </div>
    <?php endif; ?>

    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
        <tr align="center">
            <th>STT</th>
            <th>Tiêu đề</th>
            <th>Data</th>
            <th>Sửa</th>
            <th>Xóa</th>
        </tr>
        <?php $i =1; ?>
         <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr class="odd gradeX" align="center" >
             <td><?php echo e($i++); ?></td>
             <td><?php echo e($dt->tieude); ?></td>
             <td><a href="tinnhanh/<?php echo e($dt->filename); ?>"><?php echo e($dt->filename); ?></a></td>
             <td><button class="btn btn-primary"><a style="color: seashell" href="admin/noidungsua/<?php echo e($dt->id); ?>/key/<?php echo e($key='tinnhanh'); ?>"><i class="fas fa-edit"></i></a></button></td>
             <td><button class="btn btn-danger"><a style="color: seashell" href="admin/noidungxoa/<?php echo e($dt->id); ?>/key/<?php echo e($key='tinnhanh'); ?>"><i class="far fa-trash-alt"></i></a></button></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

   

    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thptvanhoi\resources\views/admin/quanly/tinnhanh.blade.php ENDPATH**/ ?>