<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Đăng Ký</title>
</head>
<body>


<h1>Đăng ký</h1>
<br>
<form action="<?php echo e(route('dangkytaikhoan')); ?>" method="post">
    <?php echo e(csrf_field()); ?>


    <input type="text" name="username" id="username" placeholder="user - name">
    <br>
    <input type="password" name="password" id="password">
    <br>
    <input type="text" name="email" id="email">
    <br>
    <button type="submit" id="btnsubmit">đăng ký</button>


    <p><?php echo e(route('dangkytaikhoan')); ?></p>
</form>

	
</body>
</html><?php /**PATH C:\xampp\htdocs\Shop\resources\views/dangkytk.blade.php ENDPATH**/ ?>