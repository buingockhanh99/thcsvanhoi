<!DOCTYPE html>
<html lang="vi">

<head>
    <title>Trường THPT Vân Hội</title>
    <meta name="author" content="Trường THPT Vân Hội">
    <meta name="copyright" content="Trường THPT Lê Quý Đôn [webmaster@vinades.vn]">
    <meta name="generator" content="NukeViet v4.4">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta property="og:title" content="Trường THPT Lê Quý Đôn">
    <meta property="og:type" content="website">
    <meta property="og:description" content="Tin Tức - Tin Tức - https&#x3A;&#x002F;&#x002F;thptlequydon.edu.vn&#x002F;">
    <meta property="og:site_name" content="Trường THPT Lê Quý Đôn">
    <meta property="og:url" content="https://thptlequydon.edu.vn/">
    
    <link rel="shortcut icon" href="/uploads/thptlequydon/logo_130_130.png">
    <link rel="preload" as="script" href="<?php echo e(asset('js/jquery.min.js')); ?>">
    <link rel="preload" as="script" href="<?php echo e(asset('js/vi.js')); ?>">
    <link rel="preload" as="script" href="<?php echo e(asset('js/global.js')); ?>">
    <link rel="preload" as="script" href="<?php echo e(asset('js/news.js')); ?>">
    <link rel="preload" as="script" href="<?php echo e(asset('js/main.js')); ?>">
    <link rel="preload" as="script" href="<?php echo e(asset('js/jquery.imgpreload.min.js')); ?>">
    <link rel="preload" as="script" href="<?php echo e(asset('js/jquery.slimmenu.js')); ?>">
    <link rel="preload" as="script" href="<?php echo e(asset('js/jquery-ui.min.js')); ?>">
    <link rel="preload" as="script" href="<?php echo e(asset('js/users.js')); ?>">
    <link rel="preload" as="script" href="<?php echo e(asset('js/jquery.breakingnews.js')); ?>">
    <link rel="preload" as="script" href="<?php echo e(asset('js/jquery.marquee.min.js')); ?>">
    <link rel="preload" as="script" href="<?php echo e(asset('js/jwplayer.js')); ?>">
    <link rel="preload" as="script" href="<?php echo e(asset('js/bootstrap.min.js')); ?>">
    <link rel="preload" as="script" href="<?php echo e(asset('js/contentslider.js')); ?>">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
    <link rel="StyleSheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="StyleSheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="StyleSheet" href="<?php echo e(asset('css/style.responsive.css')); ?>">
    <link rel="StyleSheet" href="<?php echo e(asset('css/news.css')); ?>">
    <link rel="StyleSheet" href="<?php echo e(asset('css/edu25.vi.1002.css')); ?>">
    <link rel="StyleSheet" href="<?php echo e(asset('css/users.css')); ?>">
    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(asset('css/slimmenu.css')); ?>" />
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/jquery.breakingnews.css')); ?>" />
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/jquery.ui.tabs.css')); ?>" />
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/contentslider.css')); ?>" />
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
</head>

<body>
    <?php if(!isset($thongbao)): ?>

    <?php else: ?>
       <?php echo $thongbao; ?>

    <?php endif; ?>  

    <div class="body-bg">
        <div class="wraper">
            <header>
                <div class="container">
                    <div id="header" class="row">
                        <div class="col-sm-24 col-md-10 logo_title">
                            <div class="logo col-sm-12 col-md-6">
                                <a title="Trường THPT Lê Quý Đôn" href="/"><img src="<?php echo e(asset('images/logo_114_114.png')); ?>" width="114" height="114" alt="Trường THPT Lê Quý Đôn" />
                                </a>
                                <h1>Trường THPT Vân Hội</h1>
                                <h2></h2>
                            </div>

                            <div class="title_banner text-center fl col-sm-12 col-md-18">
                                <p class="room"><a>Sở GD&ĐT Yên Bái</a>
                                </p>

                                <p class="school">
                                    <a data-text="THPT Vân Hội">THPT Vân Hội</a>
                                </p>
                            </div>
                        </div>

                        <div class="banner col-md-14 padding-right">
                            <img src="<?php echo e(asset('images/z2084927071035_fc00389bf2282fbc042a6fa599efa899.jpg')); ?>" width="590px" height="148px" />
                        </div>
                    </div>
                </div>
            </header>
            <nav class="second-nav" id="menusite">
                <div class="container">
                    <div class="row">
                        <div class="col-md-24">
                            <ul class="slimmenu">
                                <li>
                                    <a title="Trang nhất" href="/"><em class="fa fa-lg fa-home">&nbsp;</em> <span class="hidden-sm"> Trang nhất </span></a>
                                </li>
                                <li>
                                    <a title="Giới thiệu" href="/about/">Giới thiệu</a>
                                    <ul>
                                        <li>
                                            <a title="Tiểu sử  Lê Quý Đôn" href="/about/">Tiểu sử  Lê Quý Đôn</a>
                                        </li>

                                        <li>
                                            <a title="Lịch Sử Phát Triển" href="/about/">Lịch Sử Phát Triển</a>
                                        </li>

                                        <li>
                                            <a title="Thành Tích Đạt Được" href="/about/">Thành Tích Đạt Được</a>
                                        </li>

                                    </ul>
                                </li>
                                <li class="current">
                                    <a title="Tin Tức" href="/">Tin Tức</a>
                                    <ul>
                                        <li>
                                            <a title="Tin Chi Bộ" href="/tin-chi-bo/">Tin Chi Bộ</a>
                                        </li>

                                        <li>
                                            <a title="tin nhà trường" href="/tin-cap-truong/">tin nhà trường</a>
                                        </li>

                                        <li>
                                            <a title="Tin Đoàn Thể" href="/tin-doan-the/">Tin Đoàn Thể</a>
                                        </li>

                                    </ul>
                                </li>
                                <li>
                                    <a title="Thời khóa biểu" href="http://ngnuong.byethost7.com/">Thời khóa biểu</a>
                                </li>
                                <li>
                                    <a title="Tổ chức" href="/to-chuc/">Tổ chức</a>
                                    <ul>
                                        <li>
                                            <a title="Ban Giám Hiệu" href="/to-chuc/">Ban Giám Hiệu</a>
                                        </li>

                                        <li>
                                            <a title="Công đoàn" href="/to-chuc/">Công đoàn</a>
                                        </li>

                                        <li>
                                            <a title="Đoàn thể" href="/to-chuc/">Đoàn thể</a>
                                        </li>

                                        <li>
                                            <a title="Tổ bộ môn" href="/to-chuc/">Tổ bộ môn</a>
                                        </li>

                                    </ul>
                                </li>
                                <li>
                                    <a title="TỔ BỘ MÔN" href="/tai-nguyen/">TỔ BỘ MÔN</a>
                                    <ul>
                                        <li>
                                            <a title="Tổ Toán -Tin" href="/mon-toan/">Tổ Toán -Tin</a>
                                        </li>

                                        <li>
                                            <a title="Môn Vật Lý" href="/mon-vat-ly/">Môn Vật Lý</a>
                                        </li>

                                        <li>
                                            <a title="Môn Hóa_Sinh" href="/mon-hoa-sinh/">Môn Hóa_Sinh</a>
                                        </li>

                                        <li>
                                            <a title="Môn Ngữ Văn" href="/mon-van/">Môn Ngữ Văn</a>
                                        </li>

                                        <li>
                                            <a title="Tổ Sử Công Dân" href="/mon-su-cong-dan/">Tổ Sử Công Dân</a>
                                        </li>

                                        <li>
                                            <a title="Môn địa" href="/mon-dia/">Môn địa</a>
                                        </li>

                                        <li>
                                            <a title="Tổ Ngoại Ngữ" href="/ngoai-ngu/">Tổ Ngoại Ngữ</a>
                                        </li>

                                        <li>
                                            <a title="Thể dục_QPAN" href="/the-duc-qpan/">Thể dục_QPAN</a>
                                        </li>

                                        <li>
                                            <a title="Văn Phòng" href="/van-phong/">Văn Phòng</a>
                                        </li>

                                    </ul>
                                </li>
                                <li>
                                    <a title="Kế Hoạch" href="/page/">Kế Hoạch</a>
                                    <ul>
                                        <li>
                                            <a title="Kế hoạch Chi bộ" href="/kh-chi-bo/">Kế hoạch Chi bộ</a>
                                        </li>

                                        <li>
                                            <a title="Kế hoạch BGH" href="/ke-hoach-nha-truong/">Kế hoạch BGH</a>
                                            <ul>
                                                <li>
                                                    <a title="Kế hoạch nhà trường" href="/ke-hoach-nha-truong/">Kế hoạch nhà trường</a>
                                                </li>

                                                <li>
                                                    <a title="Kế hoạch_Huỳnh văn Thông" href="/khhuynhthong/">Kế hoạch_Huỳnh văn Thông</a>
                                                </li>

                                                <li>
                                                    <a title="Kê hoạch_Nguyễn Đức Tính" href="/khductinh/">Kê hoạch_Nguyễn Đức Tính</a>
                                                </li>

                                            </ul>
                                        </li>

                                        <li>
                                            <a title="Kế hoạch Công đoàn" href="/kh-cong-doan/">Kế hoạch Công đoàn</a>
                                        </li>

                                        <li>
                                            <a title="Kế hoạch Đoàn TN" href="/tin-doan-the/">Kế hoạch Đoàn TN</a>
                                        </li>

                                    </ul>
                                </li>
                                <li>
                                    <a title="Tuyển sinh" href="/tuyen-sinh/">Tuyển sinh</a>
                                </li>
                                <li>
                                    <a title="Ý kiến phụ huynh" href="/qa/">Ý kiến phụ huynh</a>
                                </li>
                                <li>
                                    <a title="Công khai" href="/cong-khai-th/">Công khai</a>
                                    <ul>
                                        <li>
                                            <a title="Công khai tài chính" href="/cong-khai-th/">Công khai tài chính</a>
                                        </li>

                                        <li>
                                            <a title="Công khai cơ sở vật chất" href="/cong-khai-th/">Công khai cơ sở vật chất</a>
                                        </li>

                                        <li>
                                            <a title="Công khai Đội ngũ" href="/cong-khai-th/">Công khai Đội ngũ</a>
                                        </li>

                                    </ul>
                                </li>
                                <li>
                                    <a title="Cựu học sinh" href="/contact/">Cựu học sinh</a>
                                    <ul>
                                        <li>
                                            <a title="Danh sách Ban liên lạc" href="/danh-sach-cuu-hs/">Danh sách Ban liên lạc</a>
                                        </li>

                                        <li>
                                            <a title="Hoạt động" href="/bllchs/">Hoạt động</a>
                                        </li>

                                        <li>
                                            <a title="Gương mặt cưu hs tiêu biểu" href="/guong-mat-cuu-hs-tieu-bieu/">Gương mặt cưu hs tiêu biểu</a>
                                        </li>

                                        <li>
                                            <a title="Ảnh hoạt động" href="/anh-cuu-hs/">Ảnh hoạt động</a>
                                        </li>

                                    </ul>
                                </li>
                                <li>
                                    <a title="Bảng vinh danh học sinh" href="/vinh-danh/">Bảng vinh danh học sinh</a>
                                    <ul>
                                        <li>
                                            <a title="Hs đạt giải Quốc tế" href="/vinh-danh/">Hs đạt giải Quốc tế</a>
                                        </li>

                                        <li>
                                            <a title="Giải quốc gia" href="/giai-quoc-gia/">Giải quốc gia</a>
                                        </li>

                                        <li>
                                            <a title="Học sinh giỏi cấp tỉnh" href="/giai-hsg/">Học sinh giỏi cấp tỉnh</a>
                                        </li>

                                        <li>
                                            <a title="Các cuộc thi khác" href="/giai-olympic/">Các cuộc thi khác</a>
                                        </li>

                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>
            <nav class="header-nav">
                <div class="container">
                    <div class="menu_topbar">
                        <a href="javascript:void(0);">
                            <em class="fa fa-th-list"></em>
                        </a>
                    </div>
                    <div class="contactDefault  col-xs-8 col-sm-14 col-md-12">
                    </div>
                    <div class="personalArea  col-xs-6 col-sm-5 col-md-5">
                        <div class="headerSearch">
                            <div class="input-group">
                                <input type="text" class="form-control" maxlength="60" placeholder="Tìm kiếm...">
                                <span class="input-group-btn"><button type="button" class="btn btn-info" data-url="/seek/?q=" data-minlength="3" data-click="y"><em class="fa fa-search fa-lg"></em></button></span>
                            </div>
                        </div>
                    </div>
                    <div class="social-icons col-xs-13 col-sm-9 col-md-7">
                        <div class="icon_user fr"><a href="javascript:void(0);"><em class="fa fa-user-secret"></em></a>
                        </div>
                        <div id="nv-block-login" class="text-right">
                            <a href="javascript:void(0);" class="login" onclick="modalShowByObj('#guestLogin_nv5', 'recaptchareset')">
	Đăng nhập
</a>
                            <i>&#47;</i>

                            <a href="javascript:void(0);" class="register" onclick="modalShowByObj('#guestReg_nv5', 'recaptchareset')">
	Đăng ký
</a>

                        </div>
                    </div>
                    <div id="tip" data-content="">
                        <div class="bg"></div>
                    </div>
                </div>
            </nav>
            <section>
                <div class="container" id="body">
                    <nav class="third-nav">
                        <div class="row">
                            <div class="col-md-24">
                                <div class="bg">
                                    <div class="clearfix margin-bottom margin-top-lg">
                                        <div class="col-xs-24 col-sm-14 col-md-19">
                                            <div class="breakingNews" id="bn2">
                                                <div class="bn-title">
                                                    <em class="fa fa-flag"></em>
                                                    <p>
                                                        Điểm tin nhanh
                                                    </p>
                                                </div>
                                                <ul>
                                                    <li class="clearfix">
                                                        <a title="TRƯỜNG THPT LÊ QUÝ ĐÔN TỔ CHỨC KỶ NIỆM NGÀY QUỐC TẾ PHỤ NỮ 8&#x002F;3" href="/bai-viet-moi/truong-thpt-le-quy-don-to-chuc-ky-niem-ngay-quoc-te-phu-nu-8-3-11068620.html">TRƯỜNG THPT LÊ QUÝ ĐÔN TỔ CHỨC KỶ NIỆM NGÀY QUỐC TẾ PHỤ NỮ 8&#x002F;3</a>
                                                    </li>
                                                    <li class="clearfix">
                                                        <a title="LỄ TỔNG KẾT NĂM HỌC 2017 - 2018" href="/bai-viet-moi/le-tong-ket-nam-hoc-2017-2018-11068631.html">LỄ TỔNG KẾT NĂM HỌC 2017 - 2018</a>
                                                    </li>
                                                    <li class="clearfix">
                                                        <a title="LỄ TRI ÂN VÀ TRƯỞNG THÀNH CHO HỌC SINH KHỐI 12 NIÊN KHÓA 2015 - 2018" href="/bai-viet-moi/le-tri-an-va-truong-thanh-cho-hoc-sinh-khoi-12-nien-khoa-2015-2018-11068632.html">LỄ TRI ÂN VÀ TRƯỞNG THÀNH CHO HỌC SINH KHỐI 12 NIÊN KHÓA 2015 - 2018</a>
                                                    </li>
                                                    <li class="clearfix">
                                                        <a title="LỄ KHAI GIẢNG NĂM HỌC 2018-2019" href="/bai-viet-moi/le-khai-giang-nam-hoc-2018-2019-11068640.html">LỄ KHAI GIẢNG NĂM HỌC 2018-2019</a>
                                                    </li>
                                                    <li class="clearfix">
                                                        <a title="TRƯỜNG THPT LÊ QUÝ ĐÔN TỔ CHỨC ĐÓN TẾT TRUNG THU CHO CON &#40; EM &#41; CỦA CÁN BỘ, GIÁO VIÊN VÀ NHÂN VIÊN TRONG NHÀ TRƯỜNG" href="/bai-viet-moi/truong-thpt-le-quy-don-to-chuc-vui-tet-trung-thu-cho-con-em-can-bo-giao-vien-va-nhan-vien-trong-nha-truong-11068642.html">TRƯỜNG THPT LÊ QUÝ ĐÔN TỔ CHỨC ĐÓN TẾT TRUNG THU CHO CON &#40; EM &#41; CỦA CÁN BỘ, GIÁO VIÊN VÀ NHÂN VIÊN TRONG NHÀ TRƯỜNG</a>
                                                    </li>
                                                    <li class="clearfix">
                                                        <a title="LỄ KỶ NIỆM 36 NĂM NGÀY NHÀ GIÁO VIỆT NAM" href="/bai-viet-moi/le-ky-niem-36-nam-ngay-nha-giao-viet-nam-11068649.html">LỄ KỶ NIỆM 36 NĂM NGÀY NHÀ GIÁO VIỆT NAM</a>
                                                    </li>
                                                    <li class="clearfix">
                                                        <a title="BẢNG LƯỢNG HÓA THI ĐUA - ĐOÀN TNCS HỒ CHÍ MINH NĂM HỌC 2018 - 2019" href="/su-kien/bang-luong-hoa-thi-dua-doan-tncs-ho-chi-minh-nam-hoc-2018-2019-11068650.html">BẢNG LƯỢNG HÓA THI ĐUA - ĐOÀN TNCS HỒ CHÍ MINH NĂM HỌC 2018 - 2019</a>
                                                    </li>
                                                    <li class="clearfix">
                                                        <a title="TVHN&#x3A; HỌC SINH TRƯỜNG LÊ QUÝ ĐÔN “SẴN SÀNG CHO CUỘC CÁCH MẠNG CÔNG NGHIỆP 4.0”" href="/su-kien/tvhn-hoc-sinh-truong-le-quy-don-san-sang-cho-cuoc-cach-mang-cong-nghiep-4-0-11068651.html">TVHN&#x3A; HỌC SINH TRƯỜNG LÊ QUÝ ĐÔN “SẴN SÀNG CHO CUỘC CÁCH MẠNG CÔNG NGHIỆP 4.0”</a>
                                                    </li>
                                                    <li class="clearfix">
                                                        <a title="VĂN BẢN ĐẢNG HIỆN HÀNH" href="/bai-viet-moi/van-ban-dang-hien-hanh-11068653.html">VĂN BẢN ĐẢNG HIỆN HÀNH</a>
                                                    </li>
                                                    <li class="clearfix">
                                                        <a title="Kế hoạch  học tập và làm theo tư tưởng, đạo đức, phong cách Hồ Chí Minh năm 2019" href="/thong-bao/ke-hoach-hoc-tap-va-lam-theo-tu-tuong-dao-duc-phong-cach-ho-chi-minh-nam-2019-11068656.html">Kế hoạch  học tập và làm theo tư tưởng, đạo đức, phong cách Hồ Chí Minh năm 2019</a>
                                                    </li>
                                                </ul>
                                                <div class="bn-navi">
                                                    <span></span>
                                                    <span></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xs-24 col-sm-10 col-md-5">
                                            <span class="current-time text-right fr">Thứ tư, 17/03/2021, 15:45</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </nav>
                    <div class="row">
                        <div class="col-sm-8 col-md-6">
                            <div class="panel panel-green">
                                <div class="panel-heading">
                                    Văn bản mới
                                </div>
                                <div class="panel-body">
                                    <div id="marquee-b141" class="news-home-marquee">
                                        <div class="clearfix">
                                            <ul>
                                                <li class="clearfix">
                                                    <strong><a href="/van-ban-cap-truong/cac-quyet-dinh-coi-thi-giua-hoc-ky-2-11069399.html"><i class="fa fa-file-text-o" aria-hidden="true"></i> Các quyết định coi thi giữa học kỳ 2</a></strong>
                                                    <div class="text-muted"><small></small>
                                                    </div>
                                                </li>
                                                <li class="clearfix">
                                                    <strong><a href="/lich-lam-viec-van-ban-cap-truong/lich-lam-viec-tuan-28-cua-can-bo-giao-vien-nhan-vien-va-doan-the-11069398.html"><i class="fa fa-file-text-o" aria-hidden="true"></i> Lịch làm việc tuần 28 của cán bộ - giáo viên - nhân viên và đoàn thể</a></strong>
                                                    <div class="text-muted"><small></small>
                                                    </div>
                                                </li>
                                                <li class="clearfix">
                                                    <strong><a href="/van-ban-cap-so/673-sgddt-vp-quyet-dinh-thanh-lap-hoi-dong-cham-thi-ky-thi-chon-hoc-sinh-gioi-cap-tinh-lop-9-nam-hoc-2020-2021-11069397.html"><i class="fa fa-file-text-o" aria-hidden="true"></i> 673&#x002F;SGDĐT-VP Quyết định thành lập Hội đồng chấm thi Kỳ thi chọn học sinh giỏi cấp tỉnh lớp 9 năm học 2020-2021</a></strong>
                                                    <div class="text-muted"><small></small>
                                                    </div>
                                                </li>
                                                <li class="clearfix">
                                                    <strong><a href="/van-ban-cap-so/668-sgddt-ttr-cong-van-trien-khai-y-kien-chi-dao-cua-tong-bi-thu-chu-tich-nuoc-nguyen-phu-trong-11069396.html"><i class="fa fa-file-text-o" aria-hidden="true"></i> 668&#x002F;SGDĐT-TTr Công văn triển khai ý kiến chỉ đạo của Tổng Bí thư, Chủ tịch nước Nguyễn Phú Trọng</a></strong>
                                                    <div class="text-muted"><small></small>
                                                    </div>
                                                </li>
                                                <li class="clearfix">
                                                    <strong><a href="/van-ban-cap-so/625-tb-sgddt-y-kien-ket-luan-cua-ong-ly-thanh-tam-giam-doc-so-gd-dt-tai-cuoc-hop-giao-ban-ngay-03-3-2021-11069395.html"><i class="fa fa-file-text-o" aria-hidden="true"></i> 625&#x002F;TB-SGDĐT Ý kiến kết luận của ông Lý Thanh Tâm - Giám đốc Sở GD&amp;ĐT tại cuộc họp giao ban ngày 03&#x002F;3&#x002F;2021</a></strong>
                                                    <div class="text-muted"><small></small>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="col-sm-16 col-md-18">
                            <div class="clearfix border-xanh bg-news-slider margin-bottom-lg">
                                <div class="col-xs-24 col-sm-12 col-md-13 clearfix">
                                    <div id="slider1" class="sliderwrapper">
                                        <div class="contentdiv ">
                                            <a title="Công đoàn trường THPT Lê Quý Đôn Tổ chức Tọa đàm kỉ niệm 111 năm ngày Quốc tế Phụ nữ và trao thưởng cuộc thi ảnh “Duyên dáng áo dài năm 2021”" href="/thong-bao/cong-doan-truong-thpt-le-quy-don-to-chuc-toa-dam-ki-niem-111-nam-ngay-quoc-te-phu-nu-va-trao-thuong-cuoc-thi-anh-duyen-dang-ao-dai-nam-2021-11069393.html">
                                                <img class="img-responsive" id="slImg0" src="/uploads/thptlequydon/news/hanh.jpg" alt="Công đoàn trường THPT Lê Quý Đôn Tổ chức Tọa đàm kỉ niệm 111 năm ngày Quốc tế Phụ nữ và trao thưởng cuộc thi ảnh “Duyên dáng áo dài năm 2021”" width="513" class="img-thumbnail" />
                                            </a>
                                            <div class="bg-news-sliders">
                                                <div>
                                                    <h3>
						<a title="Công đoàn trường THPT Lê Quý Đôn Tổ chức Tọa đàm kỉ niệm 111 năm ngày Quốc tế Phụ nữ và trao thưởng cuộc thi ảnh “Duyên dáng áo dài năm 2021”" href="/thong-bao/cong-doan-truong-thpt-le-quy-don-to-chuc-toa-dam-ki-niem-111-nam-ngay-quoc-te-phu-nu-va-trao-thuong-cuoc-thi-anh-duyen-dang-ao-dai-nam-2021-11069393.html">Công đoàn trường THPT Lê Quý Đôn Tổ chức Tọa đàm kỉ niệm 111 năm ngày Quốc tế Phụ nữ và trao thưởng cuộc thi ảnh “Duyên dáng áo dài năm 2021”</a>
					</h3>
                                                    <p></p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="contentdiv ">
                                            <a title="CHẮP CÁNH ƯỚC MƠ CHO CÔ HỌC TRÒ NGHÈO  NGUYỄN THỊ TUYẾT NHUNG" href="/bai-viet-moi/chap-canh-uoc-mo-cho-co-hoc-tro-ngheo-nguyen-thi-tuyet-nhung-11069375.html">
                                                <img class="img-responsive" id="slImg1" src="/uploads/thptlequydon/news/image-20210225163055-1.jpeg" alt="CHẮP CÁNH ƯỚC MƠ CHO CÔ HỌC TRÒ NGHÈO  NGUYỄN THỊ TUYẾT NHUNG" width="692" class="img-thumbnail" />
                                            </a>
                                            <div class="bg-news-sliders">
                                                <div>
                                                    <h3>
						<a title="CHẮP CÁNH ƯỚC MƠ CHO CÔ HỌC TRÒ NGHÈO  NGUYỄN THỊ TUYẾT NHUNG" href="/bai-viet-moi/chap-canh-uoc-mo-cho-co-hoc-tro-ngheo-nguyen-thi-tuyet-nhung-11069375.html">CHẮP CÁNH ƯỚC MƠ CHO CÔ HỌC TRÒ NGHÈO  NGUYỄN THỊ TUYẾT NHUNG</a>
					</h3>
                                                    <p></p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="contentdiv ">
                                            <a title="CÔNG ĐOÀN TRƯỜNG THPT LÊ QUÝ ĐÔN&#x3A; ĐẠT KẾT QUẢ ẤN TƯỢNG TRONG CUỘC THI “NÉT ĐẸP CÔNG ĐOÀN CƠ SỞ” QUA ẢNH NĂM 2020 ." href="/bai-viet-moi/cong-doan-truong-thpt-le-quy-don-dat-ket-qua-an-tuong-trong-cuoc-thi-net-dep-cong-doan-co-so-qua-anh-nam-2020-11069352.html">
                                                <img class="img-responsive" id="slImg2" src="/uploads/thptlequydon/news/image-20210118140701-2.jpeg" alt="CÔNG ĐOÀN TRƯỜNG THPT LÊ QUÝ ĐÔN&#x3A; ĐẠT KẾT QUẢ ẤN TƯỢNG TRONG CUỘC THI “NÉT ĐẸP CÔNG ĐOÀN CƠ SỞ” QUA ẢNH NĂM 2020 ." width="798" class="img-thumbnail" />
                                            </a>
                                            <div class="bg-news-sliders">
                                                <div>
                                                    <h3>
						<a title="CÔNG ĐOÀN TRƯỜNG THPT LÊ QUÝ ĐÔN&#x3A; ĐẠT KẾT QUẢ ẤN TƯỢNG TRONG CUỘC THI “NÉT ĐẸP CÔNG ĐOÀN CƠ SỞ” QUA ẢNH NĂM 2020 ." href="/bai-viet-moi/cong-doan-truong-thpt-le-quy-don-dat-ket-qua-an-tuong-trong-cuoc-thi-net-dep-cong-doan-co-so-qua-anh-nam-2020-11069352.html">CÔNG ĐOÀN TRƯỜNG THPT LÊ QUÝ ĐÔN&#x3A; ĐẠT KẾT QUẢ ẤN TƯỢNG TRONG CUỘC THI “NÉT ĐẸP CÔNG ĐOÀN CƠ SỞ” QUA ẢNH NĂM 2020 .</a>
					</h3>
                                                    <p></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="paginate-slider1" class="pagination fr">&nbsp;</div>
                                </div>
                                <div class="col-xs-24 col-sm-12 col-md-11 classtab">
                                    <div id="tabs" class="tabs">
                                        <ul>
                                            <li>
                                                <a href="#tabs-1"><span>Tin mới nhất</span></a>
                                            </li>
                                        </ul>
                                        <div id="tabs-1">
                                            <ul class="lastest-news">
                                                <li class="clearfix">
                                                    <a href="/thong-bao/cong-doan-truong-thpt-le-quy-don-to-chuc-toa-dam-ki-niem-111-nam-ngay-quoc-te-phu-nu-va-trao-thuong-cuoc-thi-anh-duyen-dang-ao-dai-nam-2021-11069393.html" title="Công đoàn trường THPT Lê Quý Đôn Tổ chức Tọa đàm kỉ niệm 111 năm ngày Quốc tế Phụ nữ và trao thưởng cuộc thi ảnh “Duyên dáng áo dài năm 2021”">
                                                        <img src="/assets/thptlequydon/news/hanh.jpg" class="img-thumbnail pull-left" width="110" />
                                                    </a>
                                                    <a title="Công đoàn trường THPT Lê Quý Đôn Tổ chức Tọa đàm kỉ niệm 111 năm ngày Quốc tế Phụ nữ và trao thưởng cuộc thi ảnh “Duyên dáng áo dài năm 2021”" class="show" href="/thong-bao/cong-doan-truong-thpt-le-quy-don-to-chuc-toa-dam-ki-niem-111-nam-ngay-quoc-te-phu-nu-va-trao-thuong-cuoc-thi-anh-duyen-dang-ao-dai-nam-2021-11069393.html">Công đoàn trường THPT Lê Quý Đôn Tổ chức Tọa đàm kỉ niệm 111 năm ngày Quốc tế Phụ nữ và trao thưởng cuộc thi ảnh “Duyên dáng áo dài năm 2021”</a>
                                                </li>
                                                <li class="clearfix">
                                                    <a href="/bai-viet-moi/chap-canh-uoc-mo-cho-co-hoc-tro-ngheo-nguyen-thi-tuyet-nhung-11069375.html" title="CHẮP CÁNH ƯỚC MƠ CHO CÔ HỌC TRÒ NGHÈO  NGUYỄN THỊ TUYẾT NHUNG">
                                                        <img src="/assets/thptlequydon/news/image-20210225163055-1.jpeg" class="img-thumbnail pull-left" width="110" />
                                                    </a>
                                                    <a title="CHẮP CÁNH ƯỚC MƠ CHO CÔ HỌC TRÒ NGHÈO  NGUYỄN THỊ TUYẾT NHUNG" class="show" href="/bai-viet-moi/chap-canh-uoc-mo-cho-co-hoc-tro-ngheo-nguyen-thi-tuyet-nhung-11069375.html">CHẮP CÁNH ƯỚC MƠ CHO CÔ HỌC TRÒ NGHÈO  NGUYỄN THỊ TUYẾT NHUNG</a>
                                                </li>
                                                <li class="clearfix">
                                                    <a href="/bai-viet-moi/cong-doan-truong-thpt-le-quy-don-dat-ket-qua-an-tuong-trong-cuoc-thi-net-dep-cong-doan-co-so-qua-anh-nam-2020-11069352.html" title="CÔNG ĐOÀN TRƯỜNG THPT LÊ QUÝ ĐÔN&#x3A; ĐẠT KẾT QUẢ ẤN TƯỢNG TRONG CUỘC THI “NÉT ĐẸP CÔNG ĐOÀN CƠ SỞ” QUA ẢNH NĂM 2020 .">
                                                        <img src="/assets/thptlequydon/news/image-20210118140701-2.jpeg" class="img-thumbnail pull-left" width="110" />
                                                    </a>
                                                    <a title="CÔNG ĐOÀN TRƯỜNG THPT LÊ QUÝ ĐÔN&#x3A; ĐẠT KẾT QUẢ ẤN TƯỢNG TRONG CUỘC THI “NÉT ĐẸP CÔNG ĐOÀN CƠ SỞ” QUA ẢNH NĂM 2020 ." class="show" href="/bai-viet-moi/cong-doan-truong-thpt-le-quy-don-dat-ket-qua-an-tuong-trong-cuoc-thi-net-dep-cong-doan-co-so-qua-anh-nam-2020-11069352.html">CÔNG ĐOÀN TRƯỜNG THPT LÊ QUÝ ĐÔN&#x3A; ĐẠT KẾT QUẢ ẤN TƯỢNG TRONG CUỘC THI “NÉT ĐẸP CÔNG ĐOÀN CƠ SỞ” QUA ẢNH NĂM 2020 .</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                            </div>
                            <div class="col-md-12">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-24">
                            <div class="panel panel-white margin-bottom">
                                <div class="nv-block-banners">
                                    <a rel="nofollow" href="/banners/click/?id=33&amp;s=b4c131324336e85ab57130eca9daf9da" onclick="this.target='_self'" title="Ý kiến phụ huynh"><img alt="Ý kiến phụ huynh" src="/uploads/thptlequydon/banners/tai-xuong_2.jpg" width="1080">
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-16 col-md-18">
                            <div class="clearfix">
                                <div class="col-xs-24 col-sm-12 col-md-12 left">
                                    <div class="panel panel-primary">
                                        <div class="panel-heading">
                                            <span><a href="/van-ban-cap-truong/">Văn bản trường</a></span>
                                        </div>
                                        <div class="panel-body">
                                            <ul>
                                                <li class="clearfix">
                                                    <div class="pull-left pubtime">
                                                        <p>Th.03</p>
                                                        <p>16</p>
                                                    </div>
                                                    <a class="show" href="/van-ban-cap-truong/cac-quyet-dinh-coi-thi-giua-hoc-ky-2-11069399.html" data-content="" data-img="" data-rel="block_tooltip">Các quyết định coi thi giữa học kỳ 2</a>
                                                </li>
                                                <li class="clearfix">
                                                    <div class="pull-left pubtime">
                                                        <p>Th.03</p>
                                                        <p>08</p>
                                                    </div>
                                                    <a class="show" href="/van-ban-cap-truong/ke-hoach-chuyen-mon-thang-3-2021-11069392.html" data-content="" data-img="" data-rel="block_tooltip">Kế hoạch chuyên môn tháng 3&#x002F;2021</a>
                                                </li>
                                                <li class="clearfix">
                                                    <div class="pull-left pubtime">
                                                        <p>Th.02</p>
                                                        <p>17</p>
                                                    </div>
                                                    <a class="show" href="/van-ban-cap-truong/lich-lam-viec-tuan-24-cua-can-bo-giao-vien-nhan-vien-va-doan-the-11069369.html" data-content="" data-img="" data-rel="block_tooltip">Lịch làm việc tuần 24 của cán bộ - giáo viên - nhân viên và đoàn thể</a>
                                                </li>
                                                <li class="clearfix">
                                                    <div class="pull-left pubtime">
                                                        <p>Th.02</p>
                                                        <p>05</p>
                                                    </div>
                                                    <a class="show" href="/van-ban-cap-truong/thanh-lap-ban-truc-tet-11069368.html" data-content="" data-img="" data-rel="block_tooltip">Thành lập Ban Trực Tết</a>
                                                </li>
                                                <li class="clearfix">
                                                    <div class="pull-left pubtime">
                                                        <p>Th.01</p>
                                                        <p>31</p>
                                                    </div>
                                                    <a class="show" href="/van-ban-cap-truong/phan-cong-nhiem-vu-lanh-dao-truong-thpt-le-quy-don-thuc-hien-tu-thang-02-2021-11069366.html" data-content="" data-img="" data-rel="block_tooltip">PHÂN CÔNG NHIỆM VỤ LÃNH ĐẠO TRƯỜNG THPT LÊ QUÝ ĐÔN &#40;Thực hiện từ tháng 02&#x002F;2021&#41;</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-xs-24 col-sm-12 col-md-12 right">
                                    <div class="panel panel-primary">
                                        <div class="panel-heading">
                                            <span><a href="/van-ban-cap-so/">Văn bản cấp sở</a></span>
                                        </div>
                                        <div class="panel-body">
                                            <ul>
                                                <li class="clearfix">
                                                    <div class="pull-left pubtime">
                                                        <p>Th.03</p>
                                                        <p>12</p>
                                                    </div>
                                                    <a class="show" href="/van-ban-cap-so/673-sgddt-vp-quyet-dinh-thanh-lap-hoi-dong-cham-thi-ky-thi-chon-hoc-sinh-gioi-cap-tinh-lop-9-nam-hoc-2020-2021-11069397.html" data-content="" data-img="" data-rel="block_tooltip">673&#x002F;SGDĐT-VP Quyết định thành lập Hội đồng chấm thi Kỳ thi chọn học sinh giỏi cấp tỉnh lớp 9 năm học 2020-2021</a>
                                                </li>
                                                <li class="clearfix">
                                                    <div class="pull-left pubtime">
                                                        <p>Th.03</p>
                                                        <p>12</p>
                                                    </div>
                                                    <a class="show" href="/van-ban-cap-so/668-sgddt-ttr-cong-van-trien-khai-y-kien-chi-dao-cua-tong-bi-thu-chu-tich-nuoc-nguyen-phu-trong-11069396.html" data-content="" data-img="" data-rel="block_tooltip">668&#x002F;SGDĐT-TTr Công văn triển khai ý kiến chỉ đạo của Tổng Bí thư, Chủ tịch nước Nguyễn Phú Trọng</a>
                                                </li>
                                                <li class="clearfix">
                                                    <div class="pull-left pubtime">
                                                        <p>Th.03</p>
                                                        <p>12</p>
                                                    </div>
                                                    <a class="show" href="/van-ban-cap-so/625-tb-sgddt-y-kien-ket-luan-cua-ong-ly-thanh-tam-giam-doc-so-gd-dt-tai-cuoc-hop-giao-ban-ngay-03-3-2021-11069395.html" data-content="" data-img="" data-rel="block_tooltip">625&#x002F;TB-SGDĐT Ý kiến kết luận của ông Lý Thanh Tâm - Giám đốc Sở GD&amp;ĐT tại cuộc họp giao ban ngày 03&#x002F;3&#x002F;2021</a>
                                                </li>
                                                <li class="clearfix">
                                                    <div class="pull-left pubtime">
                                                        <p>Th.03</p>
                                                        <p>10</p>
                                                    </div>
                                                    <a class="show" href="/van-ban-cap-so/631-qd-sgddt-thanh-lap-ban-giam-khao-hoi-thi-gv-chu-nhiem-lop-gioi-cap-thcs-thpt-cap-tinh-nam-2020-2021-11069394.html" data-content="" data-img="" data-rel="block_tooltip">631&#x002F;QĐ-SGDĐT Thành lập ban giám khảo Hội thi GV chủ nhiệm lớp giỏi cấp THCS, THPT cấp tỉnh năm 2020-2021</a>
                                                </li>
                                                <li class="clearfix">
                                                    <div class="pull-left pubtime">
                                                        <p>Th.03</p>
                                                        <p>07</p>
                                                    </div>
                                                    <a class="show" href="/van-ban-cap-so/330-kh-sgddt-ke-hoach-ung-dung-cntt-trong-xay-dung-chinh-quyen-dien-tu-chuyen-doi-so-va-bao-dam-an-toan-thong-tin-mang-nam-2021-11069391.html" data-content="" data-img="" data-rel="block_tooltip">330&#x002F;KH-SGDĐT Kế hoạch Ứng dụng CNTT trong xây dựng Chính quyền điện tử, chuyển đổi số và bảo đảm an toàn thông tin mạng năm 2021</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div class="margin-bottom">
                                <div class="nv-block-banners">
                                    <img alt="Học tập và làm theo tấm gương đạo đức Hồ Chí Minh" src="/uploads/thptlequydon/banners/baner_tam-guong-dao-duc_1.jpg" width="790">
                                </div>

                            </div>
                            <div class="news_column">
                                <div class="panel panel-default clearfix">
                                    <div class="panel-heading">
                                        <ul class="list-inline sub-list-icon" style="margin: 0">
                                            <li>
                                                <h4><a title="Lịch  làm việc" href="/lich-lam-viec-van-ban-cap-truong/" ><span>Lịch  làm việc</span></a></h4>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="panel-body">
                                        <div class="row">
                                            <div class="col-md-16 ">
                                                <a title="Lịch làm việc tuần 28 của cán bộ - giáo viên - nhân viên và đoàn thể" href="/lich-lam-viec-van-ban-cap-truong/lich-lam-viec-tuan-28-cua-can-bo-giao-vien-nhan-vien-va-doan-the-11069398.html"><img src="/uploads/thptlequydon/news/2015_11/images-1.jpg" alt="Lịch làm việc tuần 28 của cán bộ - giáo viên - nhân viên và đoàn thể" width="180" class="img-thumbnail pull-left imghome" />
                                                </a>
                                                <h3>
					<a title="Lịch làm việc tuần 28 của cán bộ - giáo viên - nhân viên và đoàn thể" href="/lich-lam-viec-van-ban-cap-truong/lich-lam-viec-tuan-28-cua-can-bo-giao-vien-nhan-vien-va-doan-the-11069398.html" >Lịch làm việc tuần 28 của cán bộ - giáo viên - nhân viên và đoàn thể</a>
				</h3>
                                                <div class="text-muted">
                                                    <ul class="list-unstyled list-inline">
                                                        <li><em class="fa fa-clock-o">&nbsp;</em> 14/03/2021 16:31</li>
                                                        <li><em class="fa fa-eye">&nbsp;</em> 85</li>
                                                        <li><em class="fa fa-comment-o">&nbsp;</em> 0</li>
                                                    </ul>
                                                </div>
                                                <p></p>
                                            </div>
                                            <div class="col-md-8  border-left-content">
                                                <ul class="related">
                                                    <li class="icon_list">
                                                        <a class="show h4" href="/lich-lam-viec-van-ban-cap-truong/lich-lam-viec-tuan-27-cua-can-bo-giao-vien-nhan-vien-va-doan-the-11069390.html" title="Lịch làm việc tuần 27 của cán bộ - giáo viên - nhân viên và đoàn thể" data-content="" data-img="/uploads/thptlequydon/news/2015_11/images-1.jpg" data-rel="tooltip" data-placement="top">Lịch làm việc tuần 27 của cán bộ - giáo viên - nhân viên và đoàn thể</a>
                                                    </li>
                                                    <li class="icon_list">
                                                        <a class="show h4" href="/lich-lam-viec-van-ban-cap-truong/lich-lam-viec-tuan-26-cua-can-bo-giao-vien-nhan-vien-va-doan-the-co-bo-sung-11069381.html" title="Lịch làm việc tuần 26 của cán bộ - giáo viên - nhân viên và đoàn thể&#40; Có bổ sung&#41;" data-content="" data-img="/uploads/thptlequydon/news/2015_11/images-1.jpg" data-rel="tooltip" data-placement="top">Lịch làm việc tuần 26 của cán bộ - giáo viên - nhân viên và đoàn thể&#40; Có bổ sung&#41;</a>
                                                    </li>
                                                    <li class="icon_list">
                                                        <a class="show h4" href="/lich-lam-viec-van-ban-cap-truong/lich-lam-viec-tuan-26-cua-can-bo-giao-vien-nhan-vien-va-doan-the-11069380.html" title="Lịch làm việc tuần 26 của cán bộ - giáo viên - nhân viên và đoàn thể" data-content="" data-img="/uploads/thptlequydon/news/2015_11/images-1.jpg" data-rel="tooltip" data-placement="top">Lịch làm việc tuần 26 của cán bộ - giáo viên - nhân viên và đoàn thể</a>
                                                    </li>
                                                    <li class="icon_list">
                                                        <a class="show h4" href="/lich-lam-viec-van-ban-cap-truong/lich-lam-viec-tuan-25-cua-can-bo-giao-vien-nhan-vien-va-doan-the-11069374.html" title="Lịch làm việc tuần 25 của cán bộ - giáo viên - nhân viên và đoàn thể" data-content="" data-img="/uploads/thptlequydon/news/2015_11/images-1.jpg" data-rel="tooltip" data-placement="top">Lịch làm việc tuần 25 của cán bộ - giáo viên - nhân viên và đoàn thể</a>
                                                    </li>
                                                    <li class="icon_list">
                                                        <a class="show h4" href="/lich-lam-viec-van-ban-cap-truong/lich-lam-viec-tuan-24-cua-can-bo-giao-vien-nhan-vien-va-doan-the-11069369.html" title="Lịch làm việc tuần 24 của cán bộ - giáo viên - nhân viên và đoàn thể" data-content="" data-img="/uploads/thptlequydon/news/2015_11/images-1.jpg" data-rel="tooltip" data-placement="top">Lịch làm việc tuần 24 của cán bộ - giáo viên - nhân viên và đoàn thể</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="news_column">
                                <div class="panel panel-default clearfix">
                                    <div class="panel-heading">
                                        <ul class="list-inline sub-list-icon" style="margin: 0">
                                            <li>
                                                <h4><a title="Tin nhà trường" href="/bai-viet-moi/" ><span>Tin nhà trường</span></a></h4>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="panel-body">
                                        <div class="row">
                                            <div class="col-md-16 ">
                                                <a title="Công đoàn trường THPT Lê Quý Đôn Tổ chức Tọa đàm kỉ niệm 111 năm ngày Quốc tế Phụ nữ và trao thưởng cuộc thi ảnh “Duyên dáng áo dài năm 2021”" href="/bai-viet-moi/cong-doan-truong-thpt-le-quy-don-to-chuc-toa-dam-ki-niem-111-nam-ngay-quoc-te-phu-nu-va-trao-thuong-cuoc-thi-anh-duyen-dang-ao-dai-nam-2021-11069393.html"><img src="/assets/thptlequydon/news/hanh.jpg" alt="Công đoàn trường THPT Lê Quý Đôn Tổ chức Tọa đàm kỉ niệm 111 năm ngày Quốc tế Phụ nữ và trao thưởng cuộc thi ảnh “Duyên dáng áo dài năm 2021”" width="180" class="img-thumbnail pull-left imghome" />
                                                </a>
                                                <h3>
					<a title="Công đoàn trường THPT Lê Quý Đôn Tổ chức Tọa đàm kỉ niệm 111 năm ngày Quốc tế Phụ nữ và trao thưởng cuộc thi ảnh “Duyên dáng áo dài năm 2021”" href="/bai-viet-moi/cong-doan-truong-thpt-le-quy-don-to-chuc-toa-dam-ki-niem-111-nam-ngay-quoc-te-phu-nu-va-trao-thuong-cuoc-thi-anh-duyen-dang-ao-dai-nam-2021-11069393.html" >Công đoàn trường THPT Lê Quý Đôn Tổ chức Tọa đàm kỉ niệm 111 năm ngày Quốc tế Phụ nữ và trao thưởng cuộc thi ảnh “Duyên dáng áo dài năm 2021”</a>
				</h3>
                                                <div class="text-muted">
                                                    <ul class="list-unstyled list-inline">
                                                        <li><em class="fa fa-clock-o">&nbsp;</em> 09/03/2021 14:08</li>
                                                        <li><em class="fa fa-eye">&nbsp;</em> 53</li>
                                                        <li><em class="fa fa-comment-o">&nbsp;</em> 0</li>
                                                    </ul>
                                                </div>
                                                <p></p>
                                            </div>
                                            <div class="col-md-8  border-left-content">
                                                <ul class="related">
                                                    <li class="icon_list">
                                                        <a class="show h4" href="/bai-viet-moi/chap-canh-uoc-mo-cho-co-hoc-tro-ngheo-nguyen-thi-tuyet-nhung-11069375.html" title="CHẮP CÁNH ƯỚC MƠ CHO CÔ HỌC TRÒ NGHÈO  NGUYỄN THỊ TUYẾT NHUNG" data-content="" data-img="/assets/thptlequydon/news/image-20210225163055-1.jpeg" data-rel="tooltip" data-placement="top">CHẮP CÁNH ƯỚC MƠ CHO CÔ HỌC TRÒ NGHÈO  NGUYỄN THỊ TUYẾT NHUNG</a>
                                                    </li>
                                                    <li class="icon_list">
                                                        <a class="show h4" href="/bai-viet-moi/cong-doan-truong-thpt-le-quy-don-dat-ket-qua-an-tuong-trong-cuoc-thi-net-dep-cong-doan-co-so-qua-anh-nam-2020-11069352.html" title="CÔNG ĐOÀN TRƯỜNG THPT LÊ QUÝ ĐÔN&#x3A; ĐẠT KẾT QUẢ ẤN TƯỢNG TRONG CUỘC THI “NÉT ĐẸP CÔNG ĐOÀN CƠ SỞ” QUA ẢNH NĂM 2020 ." data-content="" data-img="/assets/thptlequydon/news/image-20210118140701-2.jpeg" data-rel="tooltip" data-placement="top">CÔNG ĐOÀN TRƯỜNG THPT LÊ QUÝ ĐÔN&#x3A; ĐẠT KẾT QUẢ ẤN TƯỢNG TRONG CUỘC THI “NÉT ĐẸP CÔNG ĐOÀN CƠ SỞ” QUA ẢNH NĂM 2020 .</a>
                                                    </li>
                                                    <li class="icon_list">
                                                        <a class="show h4" href="/bai-viet-moi/doan-truong-thpt-le-quy-don-tong-ket-hoat-dong-chao-mung-ngay-nha-giao-viet-nam-20-11-11069309.html" title="ĐOÀN TRƯỜNG THPT LÊ QUÝ ĐÔN&#x3A; TỔNG KẾT HOẠT ĐỘNG CHÀO MỪNG NGÀY NHÀ GIÁO VIỆT NAM 20&#x002F;11" data-content="" data-img="/assets/thptlequydon/news/image-20201130095046-4.jpeg" data-rel="tooltip" data-placement="top">ĐOÀN TRƯỜNG THPT LÊ QUÝ ĐÔN&#x3A; TỔNG KẾT HOẠT ĐỘNG CHÀO MỪNG NGÀY NHÀ GIÁO VIỆT NAM 20&#x002F;11</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="news_column">
                                <div class="panel panel-default clearfix">
                                    <div class="panel-heading">
                                        <ul class="list-inline sub-list-icon" style="margin: 0">
                                            <li>
                                                <h4><a title="CÔNG ĐOÀN" href="/thong-bao/" ><span>CÔNG ĐOÀN</span></a></h4>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="panel-body">
                                        <div class="row">
                                            <div class="col-md-16 ">
                                                <a title="Công đoàn trường THPT Lê Quý Đôn Tổ chức Tọa đàm kỉ niệm 111 năm ngày Quốc tế Phụ nữ và trao thưởng cuộc thi ảnh “Duyên dáng áo dài năm 2021”" href="/thong-bao/cong-doan-truong-thpt-le-quy-don-to-chuc-toa-dam-ki-niem-111-nam-ngay-quoc-te-phu-nu-va-trao-thuong-cuoc-thi-anh-duyen-dang-ao-dai-nam-2021-11069393.html"><img src="/assets/thptlequydon/news/hanh.jpg" alt="Công đoàn trường THPT Lê Quý Đôn Tổ chức Tọa đàm kỉ niệm 111 năm ngày Quốc tế Phụ nữ và trao thưởng cuộc thi ảnh “Duyên dáng áo dài năm 2021”" width="180" class="img-thumbnail pull-left imghome" />
                                                </a>
                                                <h3>
					<a title="Công đoàn trường THPT Lê Quý Đôn Tổ chức Tọa đàm kỉ niệm 111 năm ngày Quốc tế Phụ nữ và trao thưởng cuộc thi ảnh “Duyên dáng áo dài năm 2021”" href="/thong-bao/cong-doan-truong-thpt-le-quy-don-to-chuc-toa-dam-ki-niem-111-nam-ngay-quoc-te-phu-nu-va-trao-thuong-cuoc-thi-anh-duyen-dang-ao-dai-nam-2021-11069393.html" >Công đoàn trường THPT Lê Quý Đôn Tổ chức Tọa đàm kỉ niệm 111 năm ngày Quốc tế Phụ nữ và trao thưởng cuộc thi ảnh “Duyên dáng áo dài năm 2021”</a>
				</h3>
                                                <div class="text-muted">
                                                    <ul class="list-unstyled list-inline">
                                                        <li><em class="fa fa-clock-o">&nbsp;</em> 09/03/2021 14:08</li>
                                                        <li><em class="fa fa-eye">&nbsp;</em> 53</li>
                                                        <li><em class="fa fa-comment-o">&nbsp;</em> 0</li>
                                                    </ul>
                                                </div>
                                                <p></p>
                                            </div>
                                            <div class="col-md-8  border-left-content">
                                                <ul class="related">
                                                    <li class="icon_list">
                                                        <a class="show h4" href="/thong-bao/hoi-thao-thay-co-thay-doi-vi-truong-hoc-hanh-phuc-11069310.html" title="Hội thảo &quot;Thầy cô thay đổi vì trường học hạnh phúc&quot;" data-content="Thực hiện nghị quyết của Chi bộ và phương hướng..." data-img="/assets/thptlequydon/news/z2201195542899_cf72c3b98b04f27f5b2ad6582accffa5.jpg" data-rel="tooltip" data-placement="top">Hội thảo &quot;Thầy cô thay đổi vì trường học hạnh phúc&quot;</a>
                                                    </li>
                                                    <li class="icon_list">
                                                        <a class="show h4" href="/thong-bao/toa-dam-ky-niem-90-nam-ngay-thanh-lap-hoi-lhpn-viet-nam-20-10-1910-20-10-2020-11069268.html" title="Tọa đàm kỷ niệm 90 năm ngày thành lập Hội LHPN Việt Nam &#40;20&#x002F;10&#x002F;1930-20&#x002F;10&#x002F;2020&#41;" data-content="Ngày 17&#x002F;10&#x002F;2020, Công đoàn Trường THPT Lê Quý Đôn..." data-img="/assets/thptlequydon/news/z2131382371955_514a0e394bd32274e8c28f10b27e1725.jpg" data-rel="tooltip" data-placement="top">Tọa đàm kỷ niệm 90 năm ngày thành lập Hội LHPN Việt Nam &#40;20&#x002F;10&#x002F;1930-20&#x002F;10&#x002F;2020&#41;</a>
                                                    </li>
                                                    <li class="icon_list">
                                                        <a class="show h4" href="/thong-bao/so-129-kh-thptlqd-v-v-to-chuc-cac-hoat-dong-chao-mung-ngay-thanh-lap-hoi-lhpn-viet-nam-20-10-2020-11069262.html" title="Số 129&#x002F;KH-THPTLQĐ V&#x002F;v Tổ chức các hoạt động chào mừng ngày Thành lập Hội LHPN Việt Nam 20&#x002F;10&#x002F;2020" data-content="" data-img="/uploads/thptlequydon/news/2015_11/images-1.jpg" data-rel="tooltip" data-placement="top">Số 129&#x002F;KH-THPTLQĐ V&#x002F;v Tổ chức các hoạt động chào mừng ngày Thành lập Hội LHPN Việt Nam 20&#x002F;10&#x002F;2020</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="news_column">
                                <div class="panel panel-default clearfix">
                                    <div class="panel-heading">
                                        <ul class="list-inline sub-list-icon" style="margin: 0">
                                            <li>
                                                <h4><a title="Tin Đoàn Thể" href="/su-kien/" ><span>Tin Đoàn Thể</span></a></h4>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="panel-body">
                                        <div class="row">
                                            <div class="col-md-16 ">
                                                <a title="Tổng hợp thi đua tuần 16" href="/su-kien/tong-hop-thi-dua-tuan-16-11069338.html"><img src="/assets/thptlequydon/news/co-doan_1.jpg" alt="Co doan" width="180" class="img-thumbnail pull-left imghome" />
                                                </a>
                                                <h3>
					<a title="Tổng hợp thi đua tuần 16" href="/su-kien/tong-hop-thi-dua-tuan-16-11069338.html" >Tổng hợp thi đua tuần 16</a>
				</h3>
                                                <div class="text-muted">
                                                    <ul class="list-unstyled list-inline">
                                                        <li><em class="fa fa-clock-o">&nbsp;</em> 27/12/2020 11:30</li>
                                                        <li><em class="fa fa-eye">&nbsp;</em> 163</li>
                                                        <li><em class="fa fa-comment-o">&nbsp;</em> 0</li>
                                                    </ul>
                                                </div>
                                                <p></p>
                                            </div>
                                            <div class="col-md-8  border-left-content">
                                                <ul class="related">
                                                    <li class="icon_list">
                                                        <a class="show h4" href="/su-kien/tong-hop-thi-dua-tuan-15-11069334.html" title="Tổng hợp thi đua tuần 15" data-content="" data-img="/assets/thptlequydon/news/co-doan_1.jpg" data-rel="tooltip" data-placement="top">Tổng hợp thi đua tuần 15</a>
                                                    </li>
                                                    <li class="icon_list">
                                                        <a class="show h4" href="/su-kien/tong-hop-thi-dua-tuan-14-11069328.html" title="Tổng hợp thi đua tuần 14" data-content="" data-img="/assets/thptlequydon/news/co-doan_1.jpg" data-rel="tooltip" data-placement="top">Tổng hợp thi đua tuần 14</a>
                                                    </li>
                                                    <li class="icon_list">
                                                        <a class="show h4" href="/su-kien/tong-hop-thi-dua-tuan-13-11069317.html" title="Tổng hợp thi đua tuần 13" data-content="" data-img="/assets/thptlequydon/news/co-doan_1.jpg" data-rel="tooltip" data-placement="top">Tổng hợp thi đua tuần 13</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="news_column">
                                <div class="panel panel-default clearfix">
                                    <div class="panel-heading">
                                        <ul class="list-inline sub-list-icon" style="margin: 0">
                                            <li>
                                                <h4><a title="HOẠT ĐỘNG NGOÀI GIỜ LÊN LỚP" href="/trao-doi-kinh-nghiem/" ><span>HOẠT ĐỘNG NGOÀI GIỜ LÊN LỚP</span></a></h4>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="panel-body">
                                        <div class="row">
                                            <div class="col-md-16 ">
                                                <a title="Tuyền truyền, giáo dục an toàn giao thông và triển khai chương trình &quot;An toàn giao thông cho nụ cười ngày mai&quot;" href="/trao-doi-kinh-nghiem/tuyen-truyen-giao-duc-an-toan-giao-thong-va-trien-khai-chuong-trinh-an-toan-giao-thong-cho-nu-cuoi-ngay-mai-11068729.html"><img src="/assets/thptlequydon/news/e22327857b3c9c62c52d.jpg" alt="Tuyền truyền, giáo dục an toàn giao thông và triển khai chương trình &quot;An toàn giao thông cho nụ cười ngày mai&quot;" width="180" class="img-thumbnail pull-left imghome" />
                                                </a>
                                                <h3>
					<a title="Tuyền truyền, giáo dục an toàn giao thông và triển khai chương trình &quot;An toàn giao thông cho nụ cười ngày mai&quot;" href="/trao-doi-kinh-nghiem/tuyen-truyen-giao-duc-an-toan-giao-thong-va-trien-khai-chuong-trinh-an-toan-giao-thong-cho-nu-cuoi-ngay-mai-11068729.html" >Tuyền truyền, giáo dục an toàn giao thông và triển khai chương trình &quot;An toàn giao thông cho nụ cười ngày mai&quot;</a>
				</h3>
                                                <div class="text-muted">
                                                    <ul class="list-unstyled list-inline">
                                                        <li><em class="fa fa-clock-o">&nbsp;</em> 30/09/2019 22:00</li>
                                                        <li><em class="fa fa-eye">&nbsp;</em> 851</li>
                                                        <li><em class="fa fa-comment-o">&nbsp;</em> 0</li>
                                                    </ul>
                                                </div>
                                                <p>Sáng hôm nay, Ngày 30/09/2019 gần 1000 học sinh trường THPT Lê Quý Đôn huyện Bù Đăng, tỉnh Bình Phước được tuyên truyền, phổ biến kiến thức luật an toàn giao thông ( ATGT). Đây là một hoạt động thường niên do Sở GD&ĐT Bình Phước phối hợp với Phòng CSGT - Công an tỉnh Bình Phước và hệ thống honda Dung Vượng tổ chức thực hiện.</p>
                                            </div>
                                            <div class="col-md-8  border-left-content">
                                                <ul class="related">
                                                    <li class="icon_list">
                                                        <a class="show h4" href="/trao-doi-kinh-nghiem/hoat-dong-ngoai-gio-len-lop-11068715.html" title="Hoạt động ngoài giờ lên lớp" data-content="" data-img="/uploads/thptlequydon/news/2015_11/images-1.jpg" data-rel="tooltip" data-placement="top">Hoạt động ngoài giờ lên lớp</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-8 col-md-6">
                            <div class="panel panel-white">
                                <div class="panel-heading">
                                    VIDEO
                                </div>
                                <div class="panel-body">
                                    <ul class="videotop" id="blvideo_bl145">
                                        <li class="clearfix">
                                            <div class="videoplayer_bl" id="videoContCtn_bl145_v8">
                                                <div class="cont">
                                                    <div id="videoCont_bl145_v8"></div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>

                                </div>
                            </div>

                            <div class="panel panel-white margin-bottom">
                                <div class="nv-block-banners">
                                    <img alt="Bộ giáo dục và đào tạo" src="/uploads/thptlequydon/banners/logobgd.gif" width="300">
                                </div>
                                <div class="nv-block-banners">
                                    <img alt="Mas" src="/uploads/thptlequydon/banners/24-12-2014-10-32-31-am.png" width="300">
                                </div>
                                <div class="nv-block-banners">
                                    <img alt="Vnedu" src="/uploads/thptlequydon/banners/edunet_1.png" width="300">
                                </div>
                                <div class="nv-block-banners">
                                    <img alt="Phần mềm quản lý" src="/uploads/thptlequydon/banners/emisonline.png" width="300">
                                </div>
                            </div>

                            <div class="panel panel-white">
                                <div class="panel-heading">
                                    Thư viện ảnh
                                </div>
                                <div class="panel-body">
                                    <ul class="list_album">
                                        <li class="text-center">
                                            <a href="/albums/xem-album/ANH-CHI-BO-16/" title="ẢNH CHI BỘ">
                                                <img src="/uploads/thptlequydon/albums/albums_cache/be4449d57a4c9d12c45d_bf4769b0762190a6e99e9e3ae86a11f2.jpg" class="img-thumbnail" alt="ẢNH CHI BỘ" width="105" height="63" />
                                            </a>
                                            <a href="/albums/xem-album/ANH-CHI-BO-16/" title="ẢNH CHI BỘ">ẢNH CHI BỘ</a>
                                        </li>
                                        <li class="text-center">
                                            <a href="/albums/xem-album/ANH-TRUONG-2/" title="ẢNH TRƯỜNG">
                                                <img src="/uploads/thptlequydon/albums/albums_cache/dsc_0002_33d8bfdde5853849af76dec8aa889c9b.jpg" class="img-thumbnail" alt="ẢNH TRƯỜNG" width="105" height="70" />
                                            </a>
                                            <a href="/albums/xem-album/ANH-TRUONG-2/" title="ẢNH TRƯỜNG">ẢNH TRƯỜNG</a>
                                        </li>
                                        <li class="text-center">
                                            <a href="/albums/xem-album/TO-VAN-PHONG-15/" title="TỔ VĂN PHÒNG">
                                                <img src="/uploads/thptlequydon/albums/albums_cache/be4449d57a4c9d12c45d_bf4769b0762190a6e99e9e3ae86a11f2.jpg" class="img-thumbnail" alt="TỔ VĂN PHÒNG" width="105" height="63" />
                                            </a>
                                            <a href="/albums/xem-album/TO-VAN-PHONG-15/" title="TỔ VĂN PHÒNG">TỔ VĂN PHÒNG</a>
                                        </li>
                                        <li class="text-center">
                                            <a href="/albums/xem-album/TO-TOAN-14/" title="TỔ TOÁN">
                                                <img src="/uploads/thptlequydon/albums/albums_cache/f370e686c21f25417c0e_cfbb36cc89cbbad52e5208f3d7bc79e4.jpg" class="img-thumbnail" alt="TỔ TOÁN" width="105" height="70" />
                                            </a>
                                            <a href="/albums/xem-album/TO-TOAN-14/" title="TỔ TOÁN">TỔ TOÁN</a>
                                        </li>
                                        <li class="text-center">
                                            <a href="/albums/xem-album/TO-TIN-11/" title="TỔ TIN">
                                                <img src="/uploads/thptlequydon/albums/albums_cache/79c9a4a35a3dbd63e42c_032ebca5ee9137f23ff3b5582c6d10dd.jpg" class="img-thumbnail" alt="TỔ TIN" width="105" height="70" />
                                            </a>
                                            <a href="/albums/xem-album/TO-TIN-11/" title="TỔ TIN">TỔ TIN</a>
                                        </li>
                                        <li class="text-center">
                                            <a href="/albums/xem-album/TO-LY-4/" title="TỔ LÝ">
                                                <img src="/uploads/thptlequydon/albums/albums_cache/10425462_665386276913728_3628273835736875950_n_a216adad5ef10844a69637d81573ea49.jpg" class="img-thumbnail" alt="TỔ LÝ" width="105" height="70" />
                                            </a>
                                            <a href="/albums/xem-album/TO-LY-4/" title="TỔ LÝ">TỔ LÝ</a>
                                        </li>
                                        <li class="text-center">
                                            <a href="/albums/xem-album/TO-HOA-SINH-7/" title="TỔ HÓA - SINH">
                                                <img src="/uploads/thptlequydon/albums/albums_cache/h_b256ae6c9d22286bfa87560ae90f4410.jpg" class="img-thumbnail" alt="TỔ HÓA - SINH" width="105" height="70" />
                                            </a>
                                            <a href="/albums/xem-album/TO-HOA-SINH-7/" title="TỔ HÓA - SINH">TỔ HÓA - SINH</a>
                                        </li>
                                        <li class="text-center">
                                            <a href="/albums/xem-album/TO-VAN-5/" title="TỔ VĂN">
                                                <img src="/uploads/thptlequydon/albums/albums_cache/v_d7cfc4caeeacafa85f0c11cd394559f6.jpg" class="img-thumbnail" alt="TỔ VĂN" width="105" height="70" />
                                            </a>
                                            <a href="/albums/xem-album/TO-VAN-5/" title="TỔ VĂN">TỔ VĂN</a>
                                        </li>
                                        <li class="text-center">
                                            <a href="/albums/xem-album/TO-SU-CONG-DAN-12/" title="TỔ SỬ- CÔNG DÂN">
                                                <img src="/uploads/thptlequydon/albums/albums_cache/hinh-dai-dien-cua-to_726518bac96a3fc0fb90cbdf5a0f7dc6.jpg" class="img-thumbnail" alt="TỔ SỬ- CÔNG DÂN" width="105" height="53" />
                                            </a>
                                            <a href="/albums/xem-album/TO-SU-CONG-DAN-12/" title="TỔ SỬ- CÔNG DÂN">TỔ SỬ- CÔNG DÂN</a>
                                        </li>
                                        <li class="text-center">
                                            <a href="/albums/xem-album/TO-NGOAI-NGU-10/" title="TỔ NGOẠI NGỮ">
                                                <img src="/uploads/thptlequydon/albums/albums_cache/bad3ac1983fc65a23ced_c3081ddff8e0a8f03bcc04d7af81e4df.jpg" class="img-thumbnail" alt="TỔ NGOẠI NGỮ" width="105" height="69" />
                                            </a>
                                            <a href="/albums/xem-album/TO-NGOAI-NGU-10/" title="TỔ NGOẠI NGỮ">TỔ NGOẠI NGỮ</a>
                                        </li>
                                        <li class="text-center">
                                            <a href="/albums/xem-album/TO-DIA-8/" title="TỔ ĐỊA">
                                                <img src="/uploads/thptlequydon/albums/albums_cache/d_f3e598124f624ff254f281caf5c050c3.jpg" class="img-thumbnail" alt="TỔ ĐỊA" width="105" height="60" />
                                            </a>
                                            <a href="/albums/xem-album/TO-DIA-8/" title="TỔ ĐỊA">TỔ ĐỊA</a>
                                        </li>
                                        <li class="text-center">
                                            <a href="/albums/xem-album/TO-THE-DUC-QP-13/" title="TỔ THỂ DUC- QP">
                                                <img src="/uploads/thptlequydon/albums/albums_cache/td1_beeba2a27aaabb4bd4aa84314af9da51.jpg" class="img-thumbnail" alt="TỔ THỂ DUC- QP" width="105" height="70" />
                                            </a>
                                            <a href="/albums/xem-album/TO-THE-DUC-QP-13/" title="TỔ THỂ DUC- QP">TỔ THỂ DUC- QP</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                            <div class="panel panel-white">
                                <div class="panel-heading">
                                    Thống kê truy cập
                                </div>
                                <div class="panel-body">
                                    <ul class="counter list-none display-table">
                                        <li><span><em class="fa fa-bolt fa-lg fa-horizon"></em>Đang truy cập</span><span>46</span>
                                        </li>
                                        <li><span><em class="fa fa-magic fa-lg fa-horizon"></em>Máy chủ tìm kiếm</span><span>4</span>
                                        </li>
                                        <li><span><em class="fa fa-bullseye fa-lg fa-horizon"></em>Khách viếng thăm</span><span>42</span>
                                        </li>
                                        <li><span><em class="fa fa-filter fa-lg fa-horizon margin-top-lg"></em>Hôm nay</span><span class="margin-top-lg">17,234</span>
                                        </li>
                                        <li><span><em class="fa fa-calendar-o fa-lg fa-horizon"></em>Tháng hiện tại</span><span>210,927</span>
                                        </li>
                                        <li><span><em class="fa fa-bars fa-lg fa-horizon"></em>Tổng lượt truy cập</span><span>15,374,219</span>
                                        </li>
                                    </ul>

                                </div>
                            </div>

                            <div class="panel panel-white margin-bottom">
                                <div class="nv-block-banners">
                                    <a rel="nofollow" href="/banners/click/?id=34&amp;s=a5ed8940a5fa82f1865cb684e68059d2" onclick="this.target='_blank'" title="Thời khóa biểu"><img alt="Thời khóa biểu" src="/uploads/thptlequydon/banners/tkb-2.png" width="248">
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-24 col-md-24">
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <footer id="footer">
            <div class="wraper">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-24 col-sm-24 col-md-16">
                            <span style="color:rgb(231, 76, 60);"><strong>Bản quyền thuộc về trường THPT Lê Quý Đôn<br />Địa chỉ: Thôn 2, Xã Đức Liễu, Huyện Bù Đăng, Bình Phước<br />Điện Thoại: (02713) 997579-(02713) 997319<br />Chịu trách nhiệm nội dung: Bà Lê Thị Bích Hạnh - Bí thư Chi bộ, Hiệu trưởng Nhà trường.</strong></span>

                        </div>
                        <div class="col-xs-24 col-sm-24 col-md-8 text-right">
                            <p class="vinades-copyright">Powered by <a href="http://nukeviet.vn/">NuKeViet</a> - a product of <a href="http://vinades.vn">VINADES.,JSC</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <nav class="footerNav2">
            <div class="wraper">
                <div class="container">
                    <div class="theme-change">
                        <span title="Chế độ giao diện đang hiển thị: Tự động"><em class="fa fa-random fa-lg"></em></span>
                        <a href="/?nvvithemever=d&amp;nv_redirect=AdmWY8Fa2CNZsUxY4CrqYOn9qg0uK0-q0IhoPSx7bSU%2C" title="Click để chuyển sang giao diện Máy Tính"><em class="fa fa-desktop fa-lg"></em></a>
                    </div>
                    <div class="bttop">
                        <a class="pointer"><em class="fa fa-eject fa-lg"></em></a>
                    </div>
                </div>
            </div>
        </nav>
    </div>
    <!-- SiteModal Required!!! -->
    <div id="sitemodal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <em class="fa fa-spinner fa-spin">&nbsp;</em>
                </div>
                <button type="button" class="close" data-dismiss="modal"><span class="fa fa-times"></span>
                </button>
            </div>
        </div>
    </div>
    <div class="fix_banner_left">
    </div>
    <div class="fix_banner_right">
    </div>
    <div id="timeoutsess" class="chromeframe">
        Bạn đã không sử dụng Site, <a onclick="timeoutsesscancel();" href="#">Bấm vào đây để duy trì trạng thái đăng nhập</a>. Thời gian chờ: <span id="secField"> 60 </span> giây
    </div>
    <div id="openidResult" class="nv-alert" style="display:none"></div>
    <div id="openidBt" data-result="" data-redirect=""></div>
    <div id="run_cronjobs" style="visibility:hidden;display:none;"><img alt="" src="/index.php?second=cronjobs&amp;p=g2A1n20L" width="1" height="1" />
    </div>

    <div id="guestLogin_nv5" class="hidden">
        <div class="page panel panel-default bg-lavender box-shadow">
            <div class="panel-body">
                <h2 class="text-center margin-bottom-lg">
			Thành viên đăng nhập
		</h2>
                <form autocomplete="off" novalidate method="POST" action="<?php echo e(route('login')); ?>">
                    
                   
                    <?php echo e(csrf_field()); ?>

                    <div class="form-detail">
                        <div class="form-group loginstep1">
                            <div class="input-group">
                                <span class="input-group-addon"><em class="fa fa-user fa-lg"></em></span>
                                <input type="text" id="usernamelg" class="required form-control" placeholder="Tên đăng nhập " value="" name="usernamelg" maxlength="100" >
                            </div>
                        </div>

                        <div class="form-group loginstep1">
                            <div class="input-group">
                                <span class="input-group-addon"><em class="fa fa-key fa-lg fa-fix"></em></span>
                                <input type="password" id="passwordlg" autocomplete="off" class="required form-control" placeholder="Mật khẩu" value="" name="passwordlg" maxlength="100" >
                            </div>
                        </div>
                       
                        <div class="text-center margin-bottom-lg">
                            
                            <button class="bsubmit btn btn-primary" type="submit">Đăng nhập</button>
                        </div>
                        <div class="text-center margin-bottom-lg" id="thongbao" style="color: red"></div>
                        
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div id="guestReg_nv5" class="hidden">
        <div class="page panel panel-default bg-lavender box-shadow">
            <div class="panel-body">
                <h2 class="text-center margin-bottom-lg">
			Đăng ký thành viên
		</h2>
                <div  autocomplete="off" novalidate>
                    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" id="token">
                    <div class="nv-info margin-bottom" data-default="Để đăng ký thành viên, bạn cần khai báo tất cả các ô trống dưới đây">Để đăng ký thành viên, bạn cần khai báo tất cả các ô trống dưới đây</div>

                    <div class="form-detail">
                        <div class="form-group">
                            <div>
                                <input type="text" class="required form-control" placeholder="Tên đăng nhập"  id="username" name="username" maxlength="20" data-pattern="/^(.){4,20}$/" onkeypress="validErrorHidden(this);" data-mess="Tên đăng nhập không hợp lệ: Tên đăng nhập chỉ được sử dụng chữ số và chữ cái và có từ 4 đến 20 ký tự">
                            </div>
                        </div>

                        <div class="form-group">
                            <div>
                               
                                <input type="email" class="required form-control" placeholder="Email"  id="email" name="email" maxlength="100" >
                            </div>
                        </div>

                        <div class="form-group">
                            <div>
                                <input type="password" autocomplete="off" class="password required form-control" id="password" placeholder="Mật khẩu"  name="password" maxlength="30" data-pattern="/^(.){5,20}$/" onkeypress="validErrorHidden(this);" data-mess="Mật khẩu không hợp lệ: Mật khẩu cần kết hợp số và chữ và có từ 5 đến 20 ký tự">
                            </div>
                        </div>

                        <div class="form-group">
                            <div>
                                <input type="password" autocomplete="off" class="password required form-control" id="confimpassword" placeholder="Mật khẩu"  name="confimpassword" maxlength="30" data-pattern="/^(.){5,20}$/" onkeypress="validErrorHidden(this);" data-mess="Mật khẩu không hợp lệ: Mật khẩu cần kết hợp số và chữ và có từ 5 đến 20 ký tự">
                            </div>
                        </div> 

                        <div class="text-center margin-bottom-lg">
                            <input type="submit" class="btn btn-primary" value="Đăng ký thành viên" id="btnsubmit" onclick="dangky()" />
                        </div>

                        <div class="text-center margin-bottom-lg" id="thongbao" style="color: red"></div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('js/jquery.min.js?t=1614914252')); ?>"></script>
    

    <script type="text/javascript">
    function dangky()
    {
        $(document).ready(function() {     
                    $.ajaxSetup({
                    headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                    });
                    
                    var _token = $("#token").val();
                    var username = $("#username").val().trim();
                    var password = $("#password").val().trim();
                    var confimpassword = $("#confimpassword").val().trim();
                    var email = $("#email").val().trim();
                    
                    if(username.length ==0)
                    {
                        showError('Vui lòng nhập tên đăng nhập')
                    }
                    else if (username.length <3 || username.length >30)
                    {
                        showError('Vui lòng nhập tên đăng nhập lớn hơn 3 và nhỏ hơn 30 ký tự')
                    }
                    else if(email.length == 0)
                    {
                        showError('Vui lòng nhập email')
                    }
                    else if(!email.includes('@'))
                    {
                        showError('Địa chỉ email không hợp  lệ')
                    }
                    else if (password.length == 0)
                    {
                        showError('Vui lòng nhập mật khẩu')
                    }
                    else if(password.length <8 || password.length >100)
                    {
                        showError('Vui lòng nhập mật khẩu lớn hơn 8 nhỏ hơn 100 ký tự')
                    }
                    else if(password != confimpassword)
                    {
                        showError('Mật khẩu nhập lại không khớp! Vui lòng nhập lại')
                    }
                   
                    else
                    {
                        $.ajax({
                            
                            url: "<?php echo e(route('dangky')); ?>",
                            type:'POST',
                            data: {_token:_token, username:username, password:password, email:email},
                            success:function(data){ //dữ liệu nhận về
                            $('#thongbao').fadeIn();  
                            $('#thongbao').html(data);}
                        }); 
                    }    
            });
    }


    // function dangnhap()
    // {
    //     $(document).ready(function() {     
    //                 $.ajaxSetup({
    //                 headers: {
    //                 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    //                 }
    //                 });
        
    //                 var _token = $("#tokenlg").val();
    //                 var username = $("#usernamelg").val().trim();
    //                 var password = $("#passwordlg").val().trim();
                    
    //                 if(username.length ==0)
    //                 {
    //                     showError('Vui lòng nhập tên đăng nhập')
    //                 }
                   
    //                 else if (password.length == 0)
    //                 {
    //                     showError('Vui lòng nhập mật khẩu')
    //                 }
                   
    //                 else
    //                 {
    //                     $.ajax({
    //                         url: "<?php echo e(route('login')); ?>",
    //                         type:'POST',
    //                         data: {_token:_token, username:username, password:password},
    //                         success:function(data){ //dữ liệu nhận về
    //                         $('#thongbao').fadeIn(10);  
    //                         $('#thongbao').html(data);}
    //                     }); 
    //                 }    
    //         });
    // }
        
    function showError(message){
        $('#thongbao').html(message)
        $('#thongbao').show()
    }
    </script>

    <script>
        var nv_base_siteurl = "/",
            nv_lang_data = "vi",
            nv_lang_interface = "vi",
            nv_name_variable = "nv",
            nv_fc_variable = "op",
            nv_lang_variable = "language",
            nv_module_name = "news",
            nv_func_name = "main",
            nv_is_user = 0,
            nv_my_ofs = 7,
            nv_my_abbr = "+07",
            nv_cookie_prefix = "nv4c_Cgoz2",
            nv_check_pass_mstime = 1738000,
            nv_area_admin = 0,
            nv_safemode = 0,
            theme_responsive = 1,
            nv_is_recaptcha = 1,
            nv_recaptcha_sitekey = "6LcNwC8UAAAAAMm8ZTYNygweLUQtOU0IapbDRk69",
            nv_recaptcha_type = "image",
            nv_recaptcha_elements = [];
    </script>
    <script src="<?php echo e(asset('js/vi.js?t=1614914252')); ?>"></script>
    <script src="<?php echo e(asset('js/global.js?t=1614914252')); ?>"></script>
    <script src="<?php echo e(asset('js/news.js?t=1614914252')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js?t=1614914252')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery.imgpreload.min.js?t=1614914252')); ?>"></script>
    <script type="text/javascript">
        function nv_update_picture_views(id, viewed) {
            if (id > 0) {
                $.post(script_name + '?' + nv_name_variable + '=' + nv_module_name + '&' + nv_fc_variable + '=albums&nocache=' + new Date().getTime(), 'updatepicview=1&viewed=' + viewed + '&id=' + id + '&num=' + nv_randomPassword(8), 'viewed' + id, function(res) {});
            }
            return false;
        }
        $(document).ready(function() {
            $('[rel="modalimg"]').click(function(e) {
                e.preventDefault();
                var a, b;

                a = $(this).attr('title');
                b = '<img src="' + $(this).attr('href') + '" style="width:100%">';
                modalShow(a, b);
            });

        });
    </script>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery.slimmenu.js?t=1614914252')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery-ui.min.js?t=1614914252')); ?>"></script>
    <script type="text/javascript">
        $('ul.slimmenu').slimmenu({
            resizeWidth: (theme_responsive == '1') ? 768 : 0,
            collapserTitle: '',
            easingEffect: 'easeInOutQuint',
            animSpeed: 'medium',
            indentChildren: true,
            childrenIndenter: '&nbsp;&nbsp; '
        });
    </script>
    <script type="text/javascript">
        $(".icon_user a").click(function() {
            $("#nv-block-login").slideToggle("slow");
        });
    </script>
    <script src="<?php echo e(asset('js/users.js?t=1614914252')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery.breakingnews.js?t=1614914252')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $(".breakingNews").breakingNews({
                effect: "slide-h",
                autoplay: true,
                timer: 3000,
                color: "yellow"
            });

        });
    </script>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery.marquee.min.js?t=1614914252')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#marquee-b141').marquee({
                duration: 2000 * $('#marquee-b141 li').length,
                gap: 10,
                duplicated: true,
                direction: 'up',
                startVisible: true
            });
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            $("[data-rel='block_tooltip'][data-content!='']").tooltip({
                placement: "bottom",
                html: true,
                title: function() {
                    return ($(this).data('img') == '' ? '' : '<img class="img-thumbnail pull-left margin_image" src="' + $(this).data('img') + '" width="90" />') + '<p class="text-justify">' + $(this).data('content') + '</p><div class="clearfix"></div>';
                }
            });
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            $("[data-rel='block_tooltip'][data-content!='']").tooltip({
                placement: "bottom",
                html: true,
                title: function() {
                    return ($(this).data('img') == '' ? '' : '<img class="img-thumbnail pull-left margin_image" src="' + $(this).data('img') + '" width="90" />') + '<p class="text-justify">' + $(this).data('content') + '</p><div class="clearfix"></div>';
                }
            });
        });
    </script>
    <script type="text/javascript" src="<?php echo e(asset('js/jwplayer.js?t=1614914252')); ?>"></script>
    <script type="text/javascript">
        jwplayer.key = "KzcW0VrDegOG/Vl8Wb9X3JLUql+72MdP1coaag==";
    </script>
    <script type="text/javascript">
        $(function() {
            var ele = "videoCont_bl145_v8";
            var a = $("#videoContCtn_bl145_v8").outerWidth(),
                b;
            640 < a && (a = 640);
            b = a;
            a = Math.ceil(45 * a / 80) + 4;
            $("#" + ele).parent().css({
                width: b,
                height: a,
                margin: "0 auto"
            });
            jwplayer(ele).setup({
                file: "/uploads/thptlequydon/.mp4",
                width: b,
                height: a,
                autostart: false
            });
        });
    </script>
    <script src="<?php echo e(asset('js/bootstrap.min.js?t=1614914252')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/contentslider.js?t=1614914252')); ?>"></script>
    <script type="text/javascript">
        //<![CDATA[
        $(document).ready(function() {
            var b = ["/uploads/thptlequydon/news/hanh.jpg", "/uploads/thptlequydon/news/image-20210225163055-1.jpeg", "/uploads/thptlequydon/news/image-20210118140701-2.jpeg"];
            $.imgpreload(b, function() {
                for (var c = b.length, a = 0; a < c; a++) $("#slImg" + a).attr("src", b[a]);
                featuredcontentslider.init({
                    id: "slider1",
                    contentsource: ["inline", ""],
                    toc: "#increment",
                    nextprev: ["&nbsp;", "&nbsp;"],
                    revealtype: "click",
                    enablefade: [true, 0.2],
                    autorotate: [true, 3E3],
                    onChange: function() {}
                });
                $("#tabs").tabs({
                    ajaxOptions: {
                        error: function(e, f, g, d) {
                            $(d.hash).html("Couldnt load this tab.")
                        }
                    }
                });
                $("#topnews").show()
            })
        });
        //]]>
    </script>


	
	
</body>

</html><?php /**PATH C:\xampp\htdocs\Shop\resources\views/index.blade.php ENDPATH**/ ?>