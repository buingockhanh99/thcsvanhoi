<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Đăng Ký</title>
</head>
<body>


<h1>Đăng ký</h1>
<br>
<input type="text" name="username" id="username" placeholder="user - name">
<br>
<input type="password" name="password" id="password">
<br>
<input type="text" name="email" id="email">
<br>
<button type="submit" id="btnsubmit">đăng ký</button>

	
    

	<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>


	<script type="text/javascript">
		$(document).ready(function(){
			$('#btnsubmit').click(function(){
				
				$.ajax({
					method: 'POST',
					url: "<?php echo e(route('dangkytaikhoan')); ?>",
					data: {csrf_field:"csrf_field()", username: $("#username").val(), password: $("#password").val(),email: $("#email")},
					success:function(data){
						$('#countryList').fadeIn(); 
						$('#countryList').html(data);
					}
				});
			});
		});
	</script>
    

	
</body>
</html><?php /**PATH C:\xampp\htdocs\Shop\resources\views/registration.blade.php ENDPATH**/ ?>