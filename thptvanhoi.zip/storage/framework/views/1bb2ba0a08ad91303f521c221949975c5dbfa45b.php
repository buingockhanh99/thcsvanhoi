
<?php $__env->startSection('NoiDung'); ?>

<div class="container-fluid">
    <div style="padding-left: 41%;padding-top: 3%;padding-bottom: 1%;">
        <h2 >Tạo Khóa Học</h2>
    </div>
    <form action="<?php echo e(route('PaddKhoahoc')); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

        <div  style="padding-left: 28%;">
            <table>
                <tr style="height: 45px">
                    <th style="width: 80px;">Khóa học</th>
                    <td> <input type="text" name="nambatdau" class="form-control" placeholder="Năm bắt đầu"  ></td>
                    <th>-</th>
                    <td><input type="text" name="namketthuc" class="form-control" placeholder="Năm kết thúc" ></td>             
                </tr> 
            </table>
            <div style="height: 20px"></div>
            <div style="padding-left: 9%;">
                <input type="submit" class="btn btn-primary" value="Tạo" style="width: 38.5%;" />
                <input type="reset" class="btn btn-primary"  value="Reset form">
            </div>
            <div style="height: 30px"></div>
            <?php if(count($errors)>0): ?>
            <div class="alert alert-danger" style="width: 55%; text-align: center">
                <?php $__currentLoopData = $errors ->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($err); ?><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>

            <?php if(session('thongbao')): ?>
                <div class="alert alert-success" style="width: 55%; text-align: center">
                    <?php echo e(session('thongbao')); ?>

                </div>
            <?php endif; ?>

            <?php if(session('thongbaoloi')): ?>
                <div class="alert alert-danger" style="width: 55%; text-align: center">
                    <?php echo e(session('thongbaoloi')); ?>

                </div>
            <?php endif; ?>

            
        </div>
    </form>
</div> 




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thptvanhoi\resources\views/admin/addKhoahoc.blade.php ENDPATH**/ ?>