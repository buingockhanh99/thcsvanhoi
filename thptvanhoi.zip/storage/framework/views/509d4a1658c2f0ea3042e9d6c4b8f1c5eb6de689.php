
<?php $__env->startSection('NoiDung'); ?>

<div class="container-fluid">
    <div style="padding-top: 3%;padding-bottom: 1%; text-align: center">
        <h2 >Quản lý chủ đề Ảnh</h2>
    </div>
    <div><button class="btn btn-primary" style="width: 200px;"><i class="fas fa-plus"></i><a style="color: #fff" href="<?php echo e(route('addcda')); ?>"> Thêm chủ đề mới</a></button></div>
    <div style="height: 30px;"></div>
    <?php if(session('thongbao')): ?>
    <div class="alert alert-success" style="width: 500px; margin-left: 29%; text-align: center">
        <?php echo e(session('thongbao')); ?>

    </div>
    <?php endif; ?>
    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
        <tr align="center">
            <th>STT</th>
            <th>Chủ đề</th>
            <th>Số lượng ảnh</th>
            <th>Xem</th>
        </tr>
        <?php $i =1; ?>
         <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr class="odd gradeX" align="center" style="line-height: 100px">
             <td><?php echo e($i++); ?></td>
             <td><?php echo e($dt->tenchude); ?></td>
            <?php 
            $idchude = $dt->id;
            $count = DB::table('anh')->where('idchude',$idchude)->count(); 
            ?>
             <td><?php echo e($count); ?></td>
             <td><a target="_blank" href="anh/<?php echo e($dt->id); ?>"><i class="fas fa-eye"></i></a></td>
         </tr>
      
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <div style="height: 30px;"></div>
  
  

    


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thptvanhoi\resources\views/admin/quanly/chudeanh.blade.php ENDPATH**/ ?>