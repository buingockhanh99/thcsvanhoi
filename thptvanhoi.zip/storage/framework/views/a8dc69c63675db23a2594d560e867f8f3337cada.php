
<?php $__env->startSection('NoiDung'); ?>
<div class="container-fluid">
    <div style="padding-left: 35%;padding-top: 3%;padding-bottom: 1%;">
        <h2 >Tạo tài khoản Giáo Viên</h2>
    </div>
    
    <form  action="<?php echo e(route('PaddAccoutGV')); ?>" method="POST" enctype="multipart/form-data" >
        <?php echo e(csrf_field()); ?>

        <div  style="padding-left: 35%;">
            <table>
            <tr style="height: 45px">
            <th>Tên đăng nhập</th>
                <td  style="padding-left: 5%;"><input type="text" placeholder="Tên đăng nhập" name="username" id="username"></td>
            </tr>
            <tr style="height: 45px">
                <th>Họ tên</th>
                <td  style="padding-left: 5%;"><input type="text" placeholder="Họ và tên giáo viên" name="myname"></td>
            </tr>
            <tr style="height: 45px">
            <th>Gmail</th>
                <td style="padding-left: 5%;"><input type="email" placeholder="Gmail" name="email"></td>
            </tr>
            <tr style="height: 45px">
                <th>Địa chỉ</th>
                <td style="padding-left: 5%;"><input type="text" placeholder="Địa chỉ" name="diachi"></td>
            </tr>
            <tr style="height: 45px">
                <th>Số điện thoại</th>
                <td style="padding-left: 5%;"><input type="text" placeholder="Số điện thoại" name="sdt" maxlength="10"></td>
            </tr>
            <tr style="height: 45px">
                <th>Ngày Sinh</th>
                <td style="padding-left: 5%;"><input type="date" name="date"></td>
            </tr>
            <tr style="height: 45px">
                <th>Ảnh</th>
                <td style="padding-left: 5%;"><input type="file"  name="file" id="file"></td>
            </tr>
            <tr style="height: 45px">
                <th>Giới tính</th>
                <td  style="padding-left: 5%;">
                    <input style="width: 30px;" type="radio" name="sex" value="Nam" checked>Nam
                    
                    <input style="width: 30px;" type="radio" name="sex" value="Nữ">Nữ
                </td>
            </tr>
            <tr style="height: 20px"></tr>
        </table> 
        
        <?php if(count($errors)>0): ?>
            <div class="alert alert-danger" style="width: 40%">
                <?php $__currentLoopData = $errors ->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($err); ?><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <?php if(session('thongbao')): ?>
            <div class="alert alert-success" style="width: 40%">
                <?php echo e(session('thongbao')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('thongbaoloi')): ?>
            <div class="alert alert-danger" style="width: 40%">
                <?php echo e(session('thongbaoloi')); ?>

            </div>
        <?php endif; ?>

       
        <div style="padding-left: 10%">
            <input type="submit" class="btn btn-primary" value="Đăng ký thành viên" />
            <input type="reset" class="btn btn-primary"  value="Reset form">
        </div>
        
        </div>
        
    </form>
    
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thptvanhoi\resources\views/admin/addAccoutGV.blade.php ENDPATH**/ ?>